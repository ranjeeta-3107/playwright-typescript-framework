import { test, expect } from '@playwright/test';

/**
 * MODULE 4 – ASSERTIONS
 *
 * Web-first assertions = `await expect(locator|page).toXxx()`.
 * They RETRY until the condition is true or the timeout (expect.timeout, 5s here) expires.
 * That is why you never need sleeps before assertions.
 *
 * Always `await` them! A missing await means the assertion is never checked.
 */

test.describe('locator assertions', () => {
  test('visibility: toBeVisible / toBeHidden', async ({ page }) => {
    await page.goto('/elements.html');

    await expect(page.getByRole('button', { name: 'Click me', exact: true })).toBeVisible();
    await expect(page.getByTestId('tooltip')).toBeHidden(); // has the `hidden` attribute
    await expect(page.getByText('This text does not exist')).toBeHidden(); // missing elements count as hidden
  });

  test('text: toHaveText (full match) vs toContainText (substring)', async ({ page }) => {
    await page.goto('/');
    const status = page.getByTestId('theme-status');

    await expect(status).toHaveText('Current theme: light'); // whole text
    await expect(status).toHaveText(/theme: \w+/); // regex
    await expect(status).toContainText('light'); // part of the text
  });

  test('value, attribute and class', async ({ page }) => {
    await page.goto('/elements.html');

    await expect(page.getByLabel('Prefilled field')).toHaveValue('Clear me');
    await expect(page.getByRole('link', { name: 'Download report' })).toHaveAttribute('href', '/download/report.csv');
    await expect(page.getByRole('button', { name: 'Enable it' })).toHaveClass('secondary');
    await expect(page.getByRole('button', { name: 'Enable it' })).toHaveClass(/second/);
  });

  test('count: toHaveCount', async ({ page }) => {
    await page.goto('/dynamic.html');
    const tasks = page.getByRole('list', { name: 'Tasks' }).getByRole('listitem');

    await expect(tasks).toHaveCount(2);
    await page.getByLabel('New task').fill('Prepare for interview');
    await page.getByRole('button', { name: 'Add task' }).click();
    await expect(tasks).toHaveCount(3);
  });

  test('more useful matchers: toBeChecked, toBeEnabled, toBeEmpty, toHaveCSS, toHaveAccessibleName', async ({ page }) => {
    await page.goto('/forms.html');

    await expect(page.getByLabel('Bio')).toBeEmpty();
    await expect(page.getByRole('button', { name: 'Reset' })).toBeEnabled();
    await expect(page.getByLabel('Full name')).toHaveAccessibleName('Full name');
    await expect(page.getByRole('heading', { name: 'Registration form' })).toHaveCSS('display', 'block');
  });

  test('negation with .not', async ({ page }) => {
    await page.goto('/forms.html');

    await expect(page.getByRole('checkbox', { name: 'Reading' })).not.toBeChecked();
    await expect(page.getByRole('button', { name: 'Register' })).not.toBeEnabled();
  });
});

test.describe('page assertions', () => {
  test('toHaveURL and toHaveTitle', async ({ page }) => {
    await page.goto('/forms.html');

    await expect(page).toHaveURL('/forms.html'); // relative to baseURL
    await expect(page).toHaveURL(/forms/); // regex
    await expect(page).toHaveTitle('Practice App | Registration Form');
    await expect(page).toHaveTitle(/Registration/);
  });
});

test.describe('soft assertions', () => {
  test('expect.soft – check many things, report all failures at the end', async ({ page }) => {
    await page.goto('/');

    // A failing soft assertion marks the test as failed but does NOT stop it,
    // so you see every broken thing in one run (great for checking a page's content).
    await expect.soft(page).toHaveTitle('Practice App | Home');
    await expect.soft(page.getByRole('heading', { level: 1 })).toHaveText('Playwright Practice App');
    await expect.soft(page.getByTestId('theme-status')).toContainText('light');

    // Optionally stop here if any soft assertion failed so far:
    expect(test.info().errors).toHaveLength(0);
  });

  test('a failing soft assertion lets the test continue (demonstration)', async ({ page }) => {
    // test.fail() = "this test is EXPECTED to fail". It is reported as passing when it fails.
    test.fail();
    await page.goto('/');

    await expect.soft(page.getByTestId('theme-status'), 'deliberately wrong text').toHaveText('Wrong text', { timeout: 500 });

    // Execution reached this line even though the soft assertion above failed:
    expect(test.info().errors).toHaveLength(1);
  });
});

test.describe('custom messages, polling and retry blocks', () => {
  test('custom assertion message makes failures easier to understand', async ({ page }) => {
    await page.goto('/login.html');
    await expect(page.getByRole('button', { name: 'Log in' }), 'Login button should be visible').toBeVisible();
  });

  test('expect.poll – retry a NON-locator value (e.g. an API call) until it matches', async ({ page }) => {
    await page.goto('/');
    await expect
      .poll(async () => (await page.request.get('/health')).status(), { timeout: 5_000 })
      .toBe(200);
  });

  test('expect(...).toPass – retry a whole block of code until it passes', async ({ page }) => {
    await page.goto('/table.html');
    await expect(async () => {
      const text = await page.getByTestId('page-info').textContent();
      expect(text).toBe('Page 1 of 5');
    }).toPass({ timeout: 5_000 });
  });
});
