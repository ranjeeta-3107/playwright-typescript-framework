import { test, expect } from '@playwright/test';

/**
 * MODULE 4 – AUTO-WAITING AND ACTIONABILITY
 *
 * ACTIONS auto-wait for "actionability" checks before acting:
 *   click(): element is attached, visible, stable (not animating), receives events, enabled
 *   fill():  attached, visible, enabled, editable
 *   check(): attached, visible, stable, receives events, enabled
 *
 * ASSERTIONS auto-wait too: `await expect(locator).toBeVisible()` retries until true.
 *
 * FIXED WAIT  (page.waitForTimeout(3000)): always waits the full 3s – slow when the app is
 *             fast, and still flaky when the app is slower than 3s.
 * CONDITION   (await expect(x).toBeVisible()): continues the moment the condition is met,
 *             and waits longer (up to the timeout) when the app is slow.
 */

test('assertion waits for an element that appears after 1.5 seconds', async ({ page }) => {
  await page.goto('/elements.html');
  await page.getByRole('button', { name: 'Show delayed element' }).click();

  // No sleep needed – this retries until the element is visible (max 5s).
  await expect(page.getByTestId('delayed-message')).toBeVisible();
});

test('action waits for an element to become enabled', async ({ page }) => {
  await page.goto('/elements.html');
  const disabled = page.getByRole('button', { name: 'Disabled button' });

  // Enable the button after 1 second (simulating a slow app) ...
  await page.evaluate(() => setTimeout(() => {
    (document.getElementById('disabled-btn') as HTMLButtonElement).disabled = false;
  }, 1000));

  // ... click() waits for the "enabled" check instead of failing immediately.
  await disabled.click();
  await expect(disabled).toBeEnabled();
});

test('assertion waits for network-driven content (spinner → result)', async ({ page }) => {
  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Load data' }).click();

  await expect(page.getByTestId('spinner')).toBeVisible();
  await expect(page.getByTestId('slow-result')).toHaveText('Loaded after 1500ms');
  await expect(page.getByTestId('spinner')).toBeHidden();
});

test('a timeout can be raised for one slow assertion', async ({ page }) => {
  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Load data' }).click();

  // Override the default 5s for this single assertion only.
  await expect(page.getByTestId('slow-result')).toHaveText(/Loaded/, { timeout: 10_000 });
});

test('why page.waitForTimeout() should be avoided', async ({ page }) => {
  await page.goto('/elements.html');
  await page.getByRole('button', { name: 'Show delayed element' }).click();

  // ❌ BAD:  await page.waitForTimeout(2000);
  //          Wastes 2s on fast machines, fails on slow CI machines (>2s).
  // ✅ GOOD: wait for the condition you actually care about.
  await expect(page.getByText('I appeared after a delay')).toBeVisible();

  // waitForTimeout is acceptable only for local debugging or when explicitly
  // testing time-based behaviour – never as a synchronisation tool.
});
