import { test, expect } from '@playwright/test';

/**
 * MODULE 5 – NEW TABS, POPUPS AND MULTIPLE WINDOWS
 *
 * Pattern: start waiting for the event BEFORE the action that triggers it,
 * then await the promise. Otherwise the event may fire before you listen.
 *
 *   const popupPromise = page.waitForEvent('popup');   // 1. listen
 *   await page.getByText('Open').click();               // 2. trigger
 *   const popup = await popupPromise;                   // 3. get the new page
 */

test('link with target=_blank opens a new tab (popup event)', async ({ page }) => {
  await page.goto('/windows.html');

  const newTabPromise = page.waitForEvent('popup');
  await page.getByRole('link', { name: 'Open new tab' }).click();
  const newTab = await newTabPromise;

  await expect(newTab).toHaveTitle('Practice App | New Tab');
  await expect(newTab.getByRole('heading', { name: 'New tab page' })).toBeVisible();

  // The original page is still usable.
  await expect(page.getByRole('heading', { name: 'Tabs and popups' })).toBeVisible();
  await newTab.close();
});

test('window.open() popup – interact with it, then close it', async ({ page }) => {
  await page.goto('/windows.html');

  const popupPromise = page.waitForEvent('popup');
  await page.getByRole('button', { name: 'Open popup' }).click();
  const popup = await popupPromise;
  await popup.waitForLoadState(); // make sure the popup's document has loaded

  await expect(popup.getByRole('heading', { name: 'Popup window' })).toBeVisible();
  await popup.getByLabel('Your name').fill('Priya');
  await expect(page.getByTestId('popup-status')).toHaveText('Popup is open');

  // Closing from inside the popup – wait for the page "close" event.
  const closed = popup.waitForEvent('close');
  await popup.getByRole('button', { name: 'Close popup' }).click();
  await closed;
  await expect(page.getByTestId('popup-status')).toHaveText('Popup is closed');
});

test('context "page" event catches any new page in the context', async ({ page, context }) => {
  await page.goto('/windows.html');

  // context.waitForEvent('page') works for tabs opened by ANY page in this context.
  const pagePromise = context.waitForEvent('page');
  await page.getByRole('link', { name: 'Open new tab' }).click();
  const newPage = await pagePromise;

  await expect(newPage).toHaveURL(/new-tab\.html/);
  expect(context.pages()).toHaveLength(2);

  // Switch focus between tabs
  await page.bringToFront();
  await expect(page).toHaveURL(/windows\.html/);
});
