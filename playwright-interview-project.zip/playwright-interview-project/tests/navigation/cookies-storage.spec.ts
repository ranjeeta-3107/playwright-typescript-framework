import { test, expect } from '@playwright/test';
import { users } from '../../utils/test-data';

/**
 * MODULE 5 – COOKIES AND LOCAL STORAGE
 *
 * Cookies belong to the BrowserContext → use context.cookies(), addCookies(), clearCookies().
 * localStorage/sessionStorage live inside the page → use page.evaluate().
 */

test('read and add cookies through the context', async ({ page, context, baseURL }) => {
  await context.addCookies([{ name: 'consent', value: 'accepted', url: baseURL! }]);
  await page.goto('/');

  const cookies = await context.cookies();
  expect(cookies).toContainEqual(expect.objectContaining({ name: 'consent', value: 'accepted' }));

  // The browser sends the cookie with every request – visible to the server:
  const echo = await page.request.get('/api/echo');
  expect((await echo.json()).headers.cookie).toContain('consent=accepted');
});

test('login creates a session cookie; clearCookies() logs the user out', async ({ page, context }) => {
  await page.goto('/login.html');
  await page.getByLabel('Username').fill(users.standard.username);
  await page.getByLabel('Password').fill(users.standard.password);
  await page.getByRole('button', { name: 'Log in' }).click();
  await expect(page).toHaveURL(/dashboard/);

  const session = (await context.cookies()).find((c) => c.name === 'session');
  expect(session?.httpOnly).toBe(true);

  await context.clearCookies();
  await page.goto('/dashboard.html');
  await expect(page).toHaveURL(/login\.html/); // redirected because the session is gone
});

test('read and write localStorage with page.evaluate()', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Toggle theme' }).click();

  const theme = await page.evaluate(() => localStorage.getItem('theme'));
  expect(theme).toBe('dark');

  await page.evaluate(() => localStorage.setItem('theme', 'light'));
  await page.reload();
  await expect(page.getByTestId('theme-status')).toHaveText('Current theme: light');
});

test('context.storageState() returns cookies AND localStorage in one object', async ({ page, context }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Toggle theme' }).click();

  const state = await context.storageState();
  const origin = state.origins.find((o) => o.origin.includes('localhost'));
  expect(origin?.localStorage).toContainEqual({ name: 'theme', value: 'dark' });
});
