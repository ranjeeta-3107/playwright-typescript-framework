import { test, expect } from '@playwright/test';

/**
 * MODULE 5 – BROWSER, BROWSERCONTEXT AND PAGE
 *
 *   Browser         – one running browser process (Chromium / Firefox / WebKit). Expensive to start.
 *   BrowserContext  – an isolated "incognito profile" inside the browser: own cookies,
 *                     localStorage, cache, permissions. Cheap to create.
 *   Page            – one tab inside a context.
 *
 * Playwright gives EVERY test a new context + page, so tests never share
 * cookies or storage. That isolation is what makes parallel execution safe.
 */

test('navigation: goto, reload, goBack, goForward', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('navigation').getByRole('link', { name: 'Forms' }).click();
  await expect(page).toHaveURL(/forms\.html/);

  await page.goBack();
  await expect(page).toHaveURL(/\/$/);

  await page.goForward();
  await expect(page).toHaveURL(/forms\.html/);

  await page.getByLabel('Full name').fill('typed before reload');
  await page.reload();
  await expect(page.getByLabel('Full name')).toHaveValue(''); // reload resets the page
});

test('one context can have multiple pages (tabs) that share cookies', async ({ context }) => {
  const page1 = await context.newPage();
  const page2 = await context.newPage();

  await page1.goto('/');
  await page2.goto('/forms.html');

  expect(context.pages()).toHaveLength(2);
  await expect(page1).toHaveTitle(/Home/);
  await expect(page2).toHaveTitle(/Registration Form/);

  // Pages in the same context share storage: login in one tab = logged in in the other.
  await page1.evaluate(() => localStorage.setItem('shared', 'yes'));
  expect(await page2.evaluate(() => localStorage.getItem('shared'))).toBe('yes');
});

test('separate contexts are completely isolated (e.g. two different users)', async ({ browser }) => {
  // Create two independent "incognito windows".
  const adminContext = await browser.newContext();
  const guestContext = await browser.newContext();
  const adminPage = await adminContext.newPage();
  const guestPage = await guestContext.newPage();

  await adminPage.goto('/');
  await adminPage.getByRole('button', { name: 'Toggle theme' }).click();
  await expect(adminPage.getByTestId('theme-status')).toHaveText('Current theme: dark');

  // The guest context does NOT see the admin's localStorage.
  await guestPage.goto('/');
  await expect(guestPage.getByTestId('theme-status')).toHaveText('Current theme: light');

  // Contexts you create yourself must be closed yourself.
  await adminContext.close();
  await guestContext.close();
});
