import { test, expect } from '@playwright/test';

/**
 * MODULE 2 – MULTIPLE MATCHES, STRICT MODE AND TABLES
 *
 * STRICT MODE: an ACTION (click, fill, ...) on a locator that matches more than
 * one element throws "strict mode violation". Playwright refuses to guess which
 * element you meant. Fix it by making the locator more specific, by chaining,
 * by filtering, or – only if order really is meaningful – with first()/last()/nth().
 */

test('strict mode violation happens when a locator matches several elements', async ({ page }) => {
  await page.goto('/');

  // Two links named "Login": one in the nav bar and one in the "Practice pages" list.
  const loginLinks = page.getByRole('link', { name: 'Login' });
  await expect(loginLinks).toHaveCount(2);

  // Clicking it would throw. We catch the error to SHOW the message (don't do this in real tests).
  const error = await loginLinks.click({ timeout: 2_000 }).catch((e: Error) => e);
  expect(error).toBeInstanceOf(Error);
  expect((error as Error).message).toContain('strict mode violation');

  // ✅ Fix: scope the locator so that it is unique.
  await page.getByRole('list', { name: 'Practice pages' }).getByRole('link', { name: 'Login' }).click();
  await expect(page).toHaveURL(/login/);
});

test('first(), last() and nth() pick by position (zero-based nth)', async ({ page }) => {
  await page.goto('/forms.html');

  const genderRadios = page.getByRole('radio');
  await expect(genderRadios).toHaveCount(3);

  await expect(genderRadios.first()).toHaveAttribute('value', 'male');
  await expect(genderRadios.nth(1)).toHaveAttribute('value', 'female');
  await expect(genderRadios.last()).toHaveAttribute('value', 'other');
});

test('iterate over all matches with all() and allTextContents()', async ({ page }) => {
  await page.goto('/forms.html');

  const options = page.getByLabel('Country').locator('option');

  // allTextContents(): one array of strings – great for comparing whole lists.
  expect(await options.allTextContents()).toEqual([
    'Select a country',
    'India',
    'United States',
    'United Kingdom',
    'Germany',
  ]);

  // all(): an array of Locators to loop through.
  for (const option of await options.all()) {
    await expect(option).toHaveAttribute('value', /.*/);
  }

  // For assertions, prefer retrying checks such as toHaveCount / toHaveText([...]).
  await expect(page.getByRole('checkbox')).toHaveCount(4);
});

test.describe('tables', () => {
  test('read a specific cell by row text and column position', async ({ page }) => {
    await page.goto('/table.html');

    const table = page.getByRole('table', { name: 'Employees' });
    const rows = table.locator('tbody tr');
    await expect(rows).toHaveCount(5); // 5 rows per page

    // Find the row for employee #3 and read its "Department" (4th column, index 3).
    const row = rows.filter({ has: page.getByRole('cell', { name: '3', exact: true }) });
    await expect(row.getByRole('cell').nth(3)).toHaveText('Marketing');

    // Header cells
    await expect(table.getByRole('columnheader')).toHaveText(['ID', 'Name', 'Email', 'Department', 'Status']);
  });

  test('collect a whole column into an array', async ({ page }) => {
    await page.goto('/table.html');

    const ids = page.getByRole('table', { name: 'Employees' }).locator('tbody tr td:nth-child(1)');
    await expect(ids).toHaveText(['1', '2', '3', '4', '5']);

    const departments = await page.locator('tbody tr td:nth-child(4)').allTextContents();
    expect(departments).toEqual(['Engineering', 'Sales', 'Marketing', 'Finance', 'Support']);
  });
});

test('best practice: prefer user-facing locators over DOM structure', async ({ page }) => {
  await page.goto('/dynamic.html');

  // ❌ The id of this button is random on every load – `#btn-abc123` would break.
  // ❌ `section:nth-child(5) > button` breaks when the layout changes.
  // ✅ The role + name is what the user sees; it survives refactors.
  await page.getByRole('button', { name: 'Dynamic ID button' }).click();
  await expect(page.getByTestId('dynamic-id-result')).toHaveText('Clicked dynamic button');
});
