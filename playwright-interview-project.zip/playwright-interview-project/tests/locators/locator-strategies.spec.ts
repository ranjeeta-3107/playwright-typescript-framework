import { test, expect } from '@playwright/test';

/**
 * MODULE 2 – LOCATOR STRATEGIES
 *
 * A Locator is a *recipe* for finding element(s). It is lazy: nothing is searched
 * until you act on it (click, fill) or assert on it. Every action re-queries the
 * DOM, so locators never go "stale" like Selenium WebElements.
 *
 * Recommended priority (most → least resilient):
 *   1. getByRole        – how users & assistive tech see the page
 *   2. getByLabel       – form fields
 *   3. getByPlaceholder – inputs without a label
 *   4. getByText        – non-interactive text
 *   5. getByAltText / getByTitle
 *   6. getByTestId      – stable contract with developers (data-testid)
 *   7. CSS / XPath      – last resort; tied to DOM structure
 */

test.describe('built-in locators (recommended)', () => {
  test('getByRole – buttons, links, headings, checkboxes by accessible name', async ({ page }) => {
    await page.goto('/forms.html');

    await expect(page.getByRole('heading', { name: 'Registration form' })).toBeVisible();
    await expect(page.getByRole('button', { name: 'Register' })).toBeDisabled();
    await expect(page.getByRole('radio', { name: 'Female' })).not.toBeChecked();
    await expect(page.getByRole('combobox', { name: 'Country' })).toBeVisible();
    // `exact: true` – match the full name only, case-sensitive.
    await expect(page.getByRole('checkbox', { name: 'Music', exact: true })).toBeVisible();
  });

  test('getByLabel – form controls by their <label>', async ({ page }) => {
    await page.goto('/forms.html');

    await page.getByLabel('Full name').fill('Ravi Kumar');
    await expect(page.getByLabel('Full name')).toHaveValue('Ravi Kumar');
  });

  test('getByPlaceholder – inputs by placeholder text', async ({ page }) => {
    await page.goto('/forms.html');

    await page.getByPlaceholder('name@example.com').fill('ravi@example.com');
    await expect(page.getByLabel('Email')).toHaveValue('ravi@example.com');
  });

  test('getByText – visible text (substring by default, exact on request)', async ({ page }) => {
    await page.goto('/');

    // Substring, case-insensitive match:
    await expect(page.getByText('small local application')).toBeVisible();
    // Exact match:
    await expect(page.getByText('Current theme: light', { exact: true })).toBeVisible();
    // Regular expression:
    await expect(page.getByText(/current theme: (light|dark)/i)).toBeVisible();
  });

  test('getByTestId – data-testid attributes agreed with developers', async ({ page }) => {
    await page.goto('/');

    // The attribute name is configured by `testIdAttribute` in playwright.config.ts.
    await expect(page.getByTestId('theme-status')).toHaveText('Current theme: light');
  });
});

test.describe('CSS, XPath and page.locator()', () => {
  test('page.locator() with CSS selectors', async ({ page }) => {
    await page.goto('/forms.html');

    await page.locator('#fullName').fill('By id');                // id
    await page.locator('input[name="email"]').fill('a@b.co');      // attribute
    await expect(page.locator('form#register-form select#country')).toHaveValue(''); // descendant
    await expect(page.locator('#fullName')).toHaveValue('By id');
  });

  test('page.locator() with XPath (prefix optional, "//" is auto-detected)', async ({ page }) => {
    await page.goto('/forms.html');

    await page.locator('//input[@id="fullName"]').fill('By XPath');
    await expect(page.locator('xpath=//input[@id="fullName"]')).toHaveValue('By XPath');

    // XPath can walk "up" the tree – something CSS cannot do. Still brittle: avoid when possible.
    const fieldsetOfMale = page.locator('//label[text()="Male"]/ancestor::fieldset');
    await expect(fieldsetOfMale.locator('legend')).toHaveText('Gender');
  });

  test('Playwright CSS extensions: :has-text() and :has()', async ({ page }) => {
    await page.goto('/elements.html');

    await expect(page.locator('button:has-text("Enable it")')).toBeVisible();
    await expect(page.locator('section:has(h2:text("Files")) a')).toHaveText('Download report');
  });
});

test.describe('chaining and filtering', () => {
  test('chaining – search inside another locator', async ({ page }) => {
    await page.goto('/');

    // Two "Login" links exist (nav bar + card list). Chaining narrows the scope.
    const nav = page.getByRole('navigation', { name: 'Main' });
    await expect(nav.getByRole('link', { name: 'Login' })).toHaveAttribute('href', '/login.html');
  });

  test('filter({ hasText }) and filter({ has }) – narrow a list of elements', async ({ page }) => {
    await page.goto('/dynamic.html');

    const tasks = page.getByRole('list', { name: 'Tasks' }).getByRole('listitem');

    // Keep only the item containing "Review PR", then click ITS Remove button.
    await tasks.filter({ hasText: 'Review PR' }).getByRole('button', { name: 'Remove' }).click();
    await expect(tasks).toHaveText([/Write tests/]);

    // `has` – keep elements that contain a matching child element.
    const sectionsWithInputs = page.locator('section').filter({ has: page.getByLabel('New task') });
    await expect(sectionsWithInputs).toHaveCount(1);

    // `hasNot` / `hasNotText` – the opposite filters.
    await expect(page.locator('section').filter({ hasNotText: 'Task list' })).toHaveCount(4);
  });

  test('or() and and() – combine locators', async ({ page }) => {
    await page.goto('/forms.html');

    // and(): element must match BOTH locators.
    const disabledRegister = page.getByRole('button', { name: 'Register' }).and(page.locator('[disabled]'));
    await expect(disabledRegister).toBeVisible();

    // or(): element matching EITHER locator (useful for "A or B may appear").
    const registerOrReset = page.getByRole('button', { name: 'Register' }).or(page.getByRole('button', { name: 'Reset' }));
    await expect(registerOrReset).toHaveCount(2);
  });
});

test.describe('special containers', () => {
  test('locators automatically pierce open Shadow DOM', async ({ page }) => {
    await page.goto('/shadow.html');

    // CSS and getBy* locators pass through *open* shadow roots. (XPath does not.)
    await expect(page.getByRole('heading', { name: 'Shadow User' })).toBeVisible();
    await expect(page.locator('user-card .card-title')).toHaveText('Shadow User');
  });

  test('frameLocator() – locate elements inside an iframe', async ({ page }) => {
    await page.goto('/frames.html');

    const frame = page.frameLocator('iframe[title="Contact form frame"]');
    await frame.getByLabel('Name').fill('Neha');
    await frame.getByRole('button', { name: 'Send' }).click();
    await expect(frame.getByTestId('frame-result')).toHaveText('Message sent by Neha');
  });
});
