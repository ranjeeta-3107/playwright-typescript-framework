import { test, expect, type Request, type Response } from '@playwright/test';

/**
 * MODULE 13 – LISTENING TO NETWORK TRAFFIC
 *
 * page.on('request' | 'response' | 'requestfailed' | 'requestfinished') lets you observe
 * every network call the page makes. Useful for: checking analytics calls, debugging,
 * asserting that no API call failed, measuring what a page loads.
 */

test('page.on("request") and page.on("response") record all traffic', async ({ page }) => {
  const requests: Request[] = [];
  const responses: Response[] = [];
  page.on('request', (request) => requests.push(request));
  page.on('response', (response) => responses.push(response));

  await page.goto('/table.html');
  await expect(page.locator('tbody tr')).toHaveCount(5);

  const apiCall = requests.find((r) => r.url().includes('/api/employees'));
  expect(apiCall?.method()).toBe('GET');
  expect(apiCall?.resourceType()).toBe('fetch');

  const apiResponse = responses.find((r) => r.url().includes('/api/employees'));
  expect(apiResponse?.status()).toBe(200);

  // Static resources were loaded too
  expect(requests.some((r) => r.url().endsWith('/app.css'))).toBe(true);
});

test('fail the test if any API call returns an error status', async ({ page }) => {
  const failedCalls: string[] = [];
  page.on('response', (response) => {
    if (response.url().includes('/api/') && response.status() >= 400) {
      failedCalls.push(`${response.status()} ${response.url()}`);
    }
  });

  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Load products' }).click();
  await expect(page.getByRole('list', { name: 'Product list' }).getByRole('listitem').first()).toBeVisible();

  expect(failedCalls, 'no API call should fail').toEqual([]);
});

test('inspect a request body and response body together', async ({ page }) => {
  await page.goto('/login.html');
  await page.getByLabel('Username').fill('student');
  await page.getByLabel('Password').fill('wrong');

  const responsePromise = page.waitForResponse('**/api/login');
  await page.getByRole('button', { name: 'Log in' }).click();
  const response = await responsePromise;

  // The request is available from the response
  expect(response.request().postDataJSON()).toEqual({ username: 'student', password: 'wrong' });
  expect(response.status()).toBe(401);
  expect(await response.json()).toEqual({ error: 'Invalid username or password' });
});

test('requestfailed event fires for aborted / unreachable requests', async ({ page }) => {
  const failed: string[] = [];
  page.on('requestfailed', (request) => failed.push(request.url()));

  // Force the products call to fail at the network level (see mocking.spec.ts for route()).
  await page.route('**/api/products', (route) => route.abort('connectionrefused'));

  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Load products' }).click();

  await expect(page.getByTestId('products-error')).toHaveText('Failed to load products');
  expect(failed.some((url) => url.includes('/api/products'))).toBe(true);
});
