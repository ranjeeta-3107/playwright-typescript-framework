import { test, expect } from '@playwright/test';

/**
 * MODULE 13 – NETWORK INTERCEPTION AND MOCKING WITH page.route()
 *
 *   await page.route(urlPattern, async (route) => {
 *     route.fulfill({...})   // answer with fake data – the real server is never called
 *     route.continue({...})  // let it through, optionally changing URL/headers/body
 *     route.fetch()          // call the real server, then modify the real response
 *     route.abort()          // simulate a network failure
 *   });
 *
 * Register routes BEFORE the page makes the request (usually before page.goto()).
 * Routes are per page/context and are removed when the test ends.
 */

test('mock a response – make random data predictable', async ({ page }) => {
  // The real /api/quote returns a RANDOM quote → impossible to assert. Mock it.
  await page.route('**/api/quote', (route) =>
    route.fulfill({ status: 200, json: { quote: 'Mocked quote for a stable test' } }),
  );

  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Get quote' }).click();

  await expect(page.getByTestId('quote')).toHaveText('Mocked quote for a stable test');
});

test('mock a list – test the UI with exactly the data you need', async ({ page }) => {
  await page.route('**/api/products', (route) =>
    route.fulfill({
      json: [
        { id: 1, name: 'Mocked Phone', category: 'Electronics', price: 1, inStock: true },
        { id: 2, name: 'Mocked Tablet', category: 'Electronics', price: 2, inStock: true },
      ],
    }),
  );

  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Load products' }).click();

  await expect(page.getByRole('list', { name: 'Product list' }).getByRole('listitem')).toHaveText([
    'Mocked Phone - $1',
    'Mocked Tablet - $2',
  ]);
});

test('mock an empty response (edge case that is hard to create for real)', async ({ page }) => {
  await page.route('**/api/products', (route) => route.fulfill({ json: [] }));

  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Load products' }).click();
  await expect(page.getByRole('list', { name: 'Product list' }).getByRole('listitem')).toHaveCount(0);
});

test('mock a server error – check the error message in the UI', async ({ page }) => {
  await page.route('**/api/products', (route) => route.fulfill({ status: 500, json: { error: 'Server exploded' } }));

  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Load products' }).click();
  await expect(page.getByTestId('products-error')).toHaveText('Failed to load products');
});

test('modify a REAL response with route.fetch()', async ({ page }) => {
  await page.route('**/api/products', async (route) => {
    const response = await route.fetch(); // real server call
    const products = await response.json();
    products[0].name = 'Patched Laptop'; // change one field
    await route.fulfill({ response, json: products });
  });

  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Load products' }).click();
  await expect(page.getByRole('list', { name: 'Product list' }).getByRole('listitem').first()).toHaveText('Patched Laptop - $999');
});

test('modify the REQUEST with route.continue() – add a header', async ({ page }) => {
  await page.route('**/api/echo', (route) =>
    route.continue({ headers: { ...route.request().headers(), 'x-test-run': 'modified-by-route' } }),
  );

  await page.goto('/advanced.html');
  await page.getByRole('button', { name: 'Check request headers' }).click();
  await expect(page.getByTestId('headers-result')).toHaveText('x-test-run: modified-by-route');
});

test('abort requests – e.g. block images/CSS to speed tests up', async ({ page }) => {
  await page.route('**/*.css', (route) => route.abort());

  await page.goto('/');
  // Page still works, just without styles.
  await expect(page.getByRole('heading', { name: 'Playwright Practice App' })).toBeVisible();
  const headerColor = await page.locator('header.site').evaluate((el) => getComputedStyle(el).backgroundColor);
  expect(headerColor).toBe('rgba(0, 0, 0, 0)'); // no stylesheet → transparent
});

test('simulate a slow API to test loading states', async ({ page }) => {
  await page.route('**/api/slow*', async (route) => {
    await new Promise((resolve) => setTimeout(resolve, 500)); // delay inside the mock only
    await route.fulfill({ json: { message: 'Slow mocked response' } });
  });

  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Load data' }).click();
  await expect(page.getByTestId('spinner')).toBeVisible();
  await expect(page.getByTestId('slow-result')).toHaveText('Slow mocked response');
});

test('wait for a specific (mocked) API response', async ({ page }) => {
  await page.route('**/api/quote', (route) => route.fulfill({ json: { quote: 'Waited for this' } }));
  await page.goto('/dynamic.html');

  const responsePromise = page.waitForResponse('**/api/quote');
  await page.getByRole('button', { name: 'Get quote' }).click();
  const response = await responsePromise;

  expect(await response.json()).toEqual({ quote: 'Waited for this' });
});

test('context.route() applies to every page in the context (including popups)', async ({ context, page }) => {
  await context.route('**/api/quote', (route) => route.fulfill({ json: { quote: 'From context route' } }));

  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Get quote' }).click();
  await expect(page.getByTestId('quote')).toHaveText('From context route');
});
