import { test, expect } from '../../fixtures/test-fixtures';
import { STORAGE_STATE } from '../../utils/test-data';

/**
 * END-TO-END SCENARIO – combines everything:
 *   - Fixtures:       `testProduct` creates data via the API and cleans it up,
 *                     `api` is an authenticated APIRequestContext,
 *                     `dashboardPage` injects the Page Object.
 *   - storageState:   the browser starts logged in.
 *   - Page Objects:   all UI work goes through DashboardPage.
 *   - API validation: the backend state is verified after UI actions.
 *   - Network waits:  waitForResponse confirms the UI's own API call.
 *
 * Story: an admin sees a newly added product, its price is changed in the backend,
 * the UI shows the new price, the product is deleted from the UI, and the API
 * confirms it no longer exists.
 */

test.use({ storageState: STORAGE_STATE });

test('product lifecycle: API create → UI verify → API update → UI delete → API verify', { tag: '@e2e' }, async ({
  page,
  api,
  dashboardPage,
  testProduct,
}) => {
  await test.step('product created by the fixture is visible in the dashboard', async () => {
    await dashboardPage.goto();
    await dashboardPage.search(testProduct.name);
    await expect(dashboardPage.rowFor(testProduct.name)).toContainText(`$${testProduct.price}`);
  });

  await test.step('price updated through the API is shown after reload', async () => {
    const patched = await api.patch(`/api/products/${testProduct.id}`, { data: { price: 1234 } });
    expect(patched.ok()).toBeTruthy();

    await page.reload();
    await dashboardPage.search(testProduct.name);
    await expect(dashboardPage.rowFor(testProduct.name)).toContainText('$1234');
  });

  await test.step('deleting in the UI sends DELETE to the API', async () => {
    const deleteRequest = page.waitForResponse(
      (res) => res.request().method() === 'DELETE' && res.url().endsWith(`/api/products/${testProduct.id}`),
    );
    await dashboardPage.deleteProduct(testProduct.name);
    expect((await deleteRequest).status()).toBe(204);
  });

  await test.step('API confirms the product is gone', async () => {
    const response = await api.get(`/api/products/${testProduct.id}`);
    expect(response.status()).toBe(404);
  });
});
