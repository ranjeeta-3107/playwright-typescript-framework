import { test as setup, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { STORAGE_STATE, users } from '../../utils/test-data';

/**
 * AUTHENTICATION SETUP (runs once, before the browser projects).
 *
 * The `setup` project in playwright.config.ts matches `*.setup.ts` files, and the
 * browser projects declare `dependencies: ['setup']`, so this runs first.
 *
 * It logs in through the UI ONE time and saves cookies + localStorage to a JSON
 * file (`storageState`). Tests that need a logged-in user load that file with
 *   test.use({ storageState: STORAGE_STATE })
 * and start already logged in – no repeated UI logins, so tests are faster.
 */
setup('authenticate as standard user', async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.login(users.standard.username, users.standard.password);

  // Wait until login has really finished before saving the state.
  await expect(page).toHaveURL(/dashboard/);
  await expect(page.getByTestId('welcome-message')).toContainText('Welcome');

  // Save cookies and localStorage to disk.
  await page.context().storageState({ path: STORAGE_STATE });
});
