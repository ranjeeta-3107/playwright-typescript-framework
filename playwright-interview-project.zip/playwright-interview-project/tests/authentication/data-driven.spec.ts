import { test, expect } from '../../fixtures/test-fixtures';
import { displayNames, invalidLogins, users } from '../../utils/test-data';

/**
 * MODULE 11 – DATA-DRIVEN / PARAMETERIZED TESTS
 *
 * Playwright has no special "data provider" API: just loop over data and call test()
 * for each item. Each item becomes a separate test with its own name and result.
 * Test titles must be unique – include the data in the title.
 */

test.describe('invalid logins show the right error', () => {
  for (const { title, username, password, error } of invalidLogins) {
    test(`rejects ${title}`, async ({ loginPage, page }) => {
      await loginPage.goto();
      await loginPage.login(username, password);

      await loginPage.expectErrorMessage(error);
      await expect(page).toHaveURL(/login/);
    });
  }
});

test.describe('valid accounts can log in', () => {
  // Parameterize over accounts, reading credentials lazily from environment variables.
  const accounts = [
    { role: 'standard', getUser: () => users.standard, name: displayNames.standard },
    { role: 'admin', getUser: () => users.admin, name: displayNames.admin },
  ] as const;

  for (const account of accounts) {
    test(`${account.role} user logs in`, async ({ loginPage, dashboardPage }) => {
      const { username, password } = account.getUser();
      await loginPage.goto();
      await loginPage.login(username, password);
      await dashboardPage.expectLoggedInAs(account.name);
    });
  }
});

test.describe('API-level data-driven check', () => {
  const cases = [
    { username: 'student', password: 'bad', status: 401 },
    { username: 'locked_user', password: 'Password123!', status: 403 },
  ];

  for (const { username, password, status } of cases) {
    test(`POST /api/login as "${username}" returns ${status}`, async ({ request }) => {
      const response = await request.post('/api/login', { data: { username, password } });
      expect(response.status()).toBe(status);
    });
  }
});
