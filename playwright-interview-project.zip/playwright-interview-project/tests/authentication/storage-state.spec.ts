import { test, expect } from '@playwright/test';
import { displayNames, STORAGE_STATE, users } from '../../utils/test-data';

/**
 * MODULE 11 – REUSING AUTHENTICATED SESSIONS WITH storageState
 *
 * 1. tests/authentication/auth.setup.ts logs in ONCE and saves cookies + localStorage
 *    to playwright/.auth/user.json (git-ignored – it contains a session!).
 * 2. Tests that need a logged-in user load that file:  test.use({ storageState: ... })
 * 3. They start already logged in → much faster than logging in through the UI every time.
 */

test.describe('logged in via storageState', () => {
  test.use({ storageState: STORAGE_STATE });

  test('dashboard opens directly without logging in', async ({ page }) => {
    await page.goto('/dashboard.html');
    await expect(page.getByTestId('welcome-message')).toHaveText(`Welcome, ${displayNames.standard}`);
  });

  test('the saved state contains the session cookie', async ({ context }) => {
    const cookies = await context.cookies();
    expect(cookies.map((c) => c.name)).toContain('session');
  });
});

test.describe('not logged in (default empty state)', () => {
  test('dashboard redirects to login', async ({ page }) => {
    await page.goto('/dashboard.html');
    await expect(page).toHaveURL(/login/);
  });
});

test('create a storageState for ANOTHER user on the fly (e.g. admin)', async ({ browser, request }, testInfo) => {
  // Log in through the API (fast) – the request context stores the session cookie.
  const response = await request.post('/api/login', { data: users.admin });
  expect(response.ok()).toBeTruthy();
  const adminStatePath = testInfo.outputPath('admin.json');
  await request.storageState({ path: adminStatePath });

  // Start a new browser context with that state → the browser is logged in as admin.
  const adminContext = await browser.newContext({ storageState: adminStatePath });
  const adminPage = await adminContext.newPage();
  await adminPage.goto('/dashboard.html');
  await expect(adminPage.getByTestId('welcome-message')).toHaveText(`Welcome, ${displayNames.admin}`);
  await adminContext.close();
});
