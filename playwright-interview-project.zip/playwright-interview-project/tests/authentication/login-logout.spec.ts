import { test, expect } from '../../fixtures/test-fixtures';
import { displayNames, users } from '../../utils/test-data';

/**
 * MODULE 11 – LOGIN AND LOGOUT (page objects injected by fixtures)
 */

test('login with valid credentials', { tag: '@smoke' }, async ({ loginPage, dashboardPage }) => {
  await loginPage.goto();
  await loginPage.login(users.standard.username, users.standard.password);

  await dashboardPage.expectLoggedInAs(displayNames.standard);
});

test('logout ends the session', async ({ loginPage, dashboardPage, page }) => {
  await loginPage.goto();
  await loginPage.login(users.standard.username, users.standard.password);
  await dashboardPage.expectLoggedInAs(displayNames.standard);

  await dashboardPage.logout();
  await expect(page).toHaveURL(/login\.html\?loggedOut=1/);
  await expect(loginPage.logoutMessage).toBeVisible();

  // The protected page now redirects back to login.
  await dashboardPage.goto();
  await expect(page).toHaveURL(/login\.html$/);
});

test('protected page redirects anonymous users to login', async ({ dashboardPage, page }) => {
  await dashboardPage.goto();
  await expect(page).toHaveURL(/login\.html/);
});

test('pressing Enter submits the login form', async ({ loginPage, dashboardPage }) => {
  await loginPage.goto();
  await loginPage.usernameInput.fill(users.standard.username);
  await loginPage.passwordInput.fill(users.standard.password);
  await loginPage.passwordInput.press('Enter');

  await dashboardPage.expectLoggedInAs(displayNames.standard);
});
