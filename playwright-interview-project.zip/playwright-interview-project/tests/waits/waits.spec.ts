import { test, expect } from '@playwright/test';
import { users } from '../../utils/test-data';

/**
 * MODULE 7 – WAITS AND SYNCHRONISATION
 *
 * Preferred order in modern Playwright:
 *   1. Do nothing special – actions auto-wait.
 *   2. Web-first assertions: await expect(locator).toBeVisible() / toHaveText() / toHaveURL()
 *   3. Explicit event waits when you need DATA from the event:
 *        waitForResponse / waitForRequest / waitForEvent('popup' | 'download' | 'dialog')
 *   4. waitForURL / waitForLoadState – occasionally useful after navigation.
 *   5. waitForSelector / locator.waitFor() – rarely needed (old style, prefer assertions).
 *   ✗  waitForTimeout – avoid (fixed sleep).
 */

test('web-first assertion is the default way to wait', async ({ page }) => {
  await page.goto('/dynamic.html');
  await page.getByRole('button', { name: 'Load data' }).click();
  await expect(page.getByTestId('slow-result')).toHaveText('Loaded after 1500ms');
});

test('locator.waitFor() and page.waitForSelector() – wait for a state, then continue', async ({ page }) => {
  await page.goto('/elements.html');
  await page.getByRole('button', { name: 'Show delayed element' }).click();

  // Modern form: locator.waitFor() – states: attached | detached | visible | hidden
  await page.getByTestId('delayed-message').waitFor({ state: 'visible' });

  // Older form (still supported, but locators + assertions are preferred):
  const handle = await page.waitForSelector('[data-testid="delayed-message"]', { state: 'visible' });
  expect(await handle.textContent()).toBe('I appeared after a delay');
});

test('waitForLoadState() – wait for "load", "domcontentloaded" or "networkidle"', async ({ page }) => {
  await page.goto('/table.html', { waitUntil: 'domcontentloaded' });
  await page.waitForLoadState('load');

  // "networkidle" (no requests for 500ms) is DISCOURAGED for normal tests – it is slow
  // and unreliable with polling/analytics. Assert on the content you need instead:
  await expect(page.locator('tbody tr')).toHaveCount(5);
});

test('waitForURL() – wait for navigation triggered by a click/redirect', async ({ page }) => {
  await page.goto('/login.html');
  await page.getByLabel('Username').fill(users.standard.username);
  await page.getByLabel('Password').fill(users.standard.password);
  await page.getByRole('button', { name: 'Log in' }).click();

  await page.waitForURL('**/dashboard.html');
  // Equivalent and usually preferred, because it is an assertion:
  await expect(page).toHaveURL(/dashboard\.html/);
});

test('waitForResponse() – wait for an API call AND inspect its data', async ({ page }) => {
  await page.goto('/dynamic.html');

  // 1. Start waiting BEFORE the action. 2. Trigger it. 3. Await the promise.
  const responsePromise = page.waitForResponse(
    (response) => response.url().includes('/api/slow') && response.status() === 200,
  );
  await page.getByRole('button', { name: 'Load data' }).click();
  const response = await responsePromise;

  expect(await response.json()).toEqual({ message: 'Loaded after 1500ms' });
  await expect(page.getByTestId('slow-result')).toHaveText('Loaded after 1500ms');
});

test('waitForRequest() – verify what the UI sends to the server', async ({ page }) => {
  await page.goto('/forms.html');
  await page.getByLabel('Full name').fill('Request Check');
  await page.getByLabel('Email').fill('request@example.com');
  await page.getByLabel('Password').fill('Password99');
  await page.getByRole('radio', { name: 'Other' }).check();
  await page.getByLabel('Country').selectOption('uk');
  await page.getByLabel('I accept the terms and conditions').check();

  const requestPromise = page.waitForRequest((req) => req.url().endsWith('/api/register') && req.method() === 'POST');
  await page.getByRole('button', { name: 'Register' }).click();
  const request = await requestPromise;

  expect(request.postDataJSON()).toMatchObject({ fullName: 'Request Check', country: 'uk', gender: 'other' });
});

test('waitForEvent() – generic waiting for page events (popup, download, dialog, console...)', async ({ page }) => {
  await page.goto('/');

  const consolePromise = page.waitForEvent('console', (msg) => msg.text() === 'hello from the page');
  await page.evaluate(() => console.log('hello from the page'));
  const message = await consolePromise;

  expect(message.type()).toBe('log');
});

test('network-dependent UI: assert on the spinner AND the final result', async ({ page }) => {
  await page.goto('/dynamic.html');

  const responsePromise = page.waitForResponse('**/api/slow?delay=1500');
  await page.getByRole('button', { name: 'Load data' }).click();

  await expect(page.getByTestId('spinner')).toBeVisible(); // loading state shown
  await responsePromise; // API finished
  await expect(page.getByTestId('spinner')).toBeHidden(); // UI updated
  await expect(page.getByTestId('slow-result')).not.toBeEmpty();
});
