import { test, expect } from '@playwright/test';

/**
 * MODULE 6 – TABLES AND PAGINATION
 */

test.beforeEach(async ({ page }) => {
  await page.goto('/table.html');
});

test('first page shows 5 employees and Previous is disabled', async ({ page }) => {
  await expect(page.getByTestId('page-info')).toHaveText('Page 1 of 5');
  await expect(page.locator('tbody tr')).toHaveCount(5);
  await expect(page.getByRole('button', { name: 'Previous' })).toBeDisabled();
});

test('Next / Previous move between pages', async ({ page }) => {
  const firstIdCell = page.locator('tbody tr').first().getByRole('cell').first();

  await page.getByRole('button', { name: 'Next' }).click();
  await expect(page.getByTestId('page-info')).toHaveText('Page 2 of 5');
  await expect(firstIdCell).toHaveText('6');

  await page.getByRole('button', { name: 'Previous' }).click();
  await expect(firstIdCell).toHaveText('1');
});

test('the last page has the remaining 3 rows and Next is disabled', async ({ page }) => {
  const next = page.getByRole('button', { name: 'Next' });
  // Click until the button is disabled. Each assertion waits for the page to update.
  for (let pageNumber = 2; pageNumber <= 5; pageNumber++) {
    await next.click();
    await expect(page.getByTestId('page-info')).toHaveText(`Page ${pageNumber} of 5`);
  }

  await expect(next).toBeDisabled();
  await expect(page.locator('tbody tr')).toHaveCount(3);
});

test('search every page for an employee (classic interview task)', async ({ page }) => {
  const wanted = 'zara22@example.com';
  const next = page.getByRole('button', { name: 'Next' });

  let found = false;
  while (!found) {
    const row = page.getByRole('row').filter({ hasText: wanted });
    // count() does not wait, so first wait for the current page's rows to render.
    await expect(page.locator('tbody tr').first()).toBeVisible();
    if ((await row.count()) > 0) {
      await expect(row.getByRole('cell').nth(1)).toHaveText('Zara V.');
      found = true;
    } else if (await next.isEnabled()) {
      const currentInfo = await page.getByTestId('page-info').textContent();
      await next.click();
      await expect(page.getByTestId('page-info')).not.toHaveText(currentInfo ?? '');
    } else {
      break;
    }
  }

  expect(found, `${wanted} should exist on one of the pages`).toBe(true);
  await expect(page.getByTestId('page-info')).toHaveText('Page 5 of 5');
});

test('count rows that match a condition', async ({ page }) => {
  const inactiveRows = page.locator('tbody tr').filter({ hasText: 'Inactive' });
  await expect(inactiveRows).toHaveCount(2); // employees 1 and 5 on page 1
});
