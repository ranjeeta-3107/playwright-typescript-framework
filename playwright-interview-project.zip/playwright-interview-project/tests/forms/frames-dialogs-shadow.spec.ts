import { test, expect } from '@playwright/test';

/**
 * MODULE 6 – IFRAMES, JAVASCRIPT DIALOGS AND SHADOW DOM
 */

test.describe('iframes', () => {
  test('frameLocator() – interact with elements inside an iframe', async ({ page }) => {
    await page.goto('/frames.html');

    // Elements inside an iframe are NOT reachable with page.getBy...; enter the frame first.
    const frame = page.frameLocator('#contact-frame');
    await frame.getByLabel('Name').fill('Arjun');
    await frame.getByRole('button', { name: 'Send' }).click();

    await expect(frame.getByTestId('frame-result')).toHaveText('Message sent by Arjun');
  });

  test('locator.contentFrame() – the same thing starting from the <iframe> locator', async ({ page }) => {
    await page.goto('/frames.html');

    const frame = page.getByTitle('Contact form frame').contentFrame();
    await frame.getByRole('button', { name: 'Send' }).click();
    await expect(frame.getByTestId('frame-result')).toHaveText('Message sent by anonymous');
  });

  test('page.frame() – access a Frame object by name or URL', async ({ page }) => {
    await page.goto('/frames.html');

    const frame = page.frame({ url: /frame-content\.html/ });
    expect(frame).not.toBeNull();
    await expect(frame!.getByRole('heading', { name: 'Contact us' })).toBeVisible();
  });
});

test.describe('JavaScript dialogs (alert, confirm, prompt)', () => {
  // By default Playwright AUTO-DISMISSES dialogs. Register a handler to accept them
  // or to read their text. The handler must be registered BEFORE the click.

  test.beforeEach(async ({ page }) => {
    await page.goto('/alerts.html');
  });

  test('alert – read the message and accept', async ({ page }) => {
    page.once('dialog', async (dialog) => {
      expect(dialog.type()).toBe('alert');
      expect(dialog.message()).toBe('Hello from an alert!');
      await dialog.accept();
    });
    await page.getByRole('button', { name: 'Show alert' }).click();
    await expect(page.getByTestId('dialog-result')).toHaveText('Alert closed');
  });

  test('confirm – accept (OK)', async ({ page }) => {
    page.once('dialog', (dialog) => dialog.accept());
    await page.getByRole('button', { name: 'Show confirm' }).click();
    await expect(page.getByTestId('dialog-result')).toHaveText('Confirm: OK');
  });

  test('confirm – dismiss (Cancel) is the default behaviour', async ({ page }) => {
    // No handler registered → Playwright dismisses the dialog automatically.
    await page.getByRole('button', { name: 'Show confirm' }).click();
    await expect(page.getByTestId('dialog-result')).toHaveText('Confirm: Cancel');
  });

  test('prompt – type an answer', async ({ page }) => {
    page.once('dialog', async (dialog) => {
      expect(dialog.type()).toBe('prompt');
      expect(dialog.defaultValue()).toBe('Guest');
      await dialog.accept('Kavya');
    });
    await page.getByRole('button', { name: 'Show prompt' }).click();
    await expect(page.getByTestId('dialog-result')).toHaveText('Prompt: Hello, Kavya');
  });

  test('prompt – waitForEvent("dialog") style', async ({ page }) => {
    const dialogPromise = page.waitForEvent('dialog');
    // The click cannot finish while the dialog is open, so do NOT await it yet.
    const clickPromise = page.getByRole('button', { name: 'Show prompt' }).click();
    const dialog = await dialogPromise;
    await dialog.dismiss();
    await clickPromise;
    await expect(page.getByTestId('dialog-result')).toHaveText('Prompt: cancelled');
  });
});

test.describe('Shadow DOM', () => {
  test('interact with elements inside an open shadow root', async ({ page }) => {
    await page.goto('/shadow.html');

    // No special API needed: getBy* and CSS locators pierce OPEN shadow roots automatically.
    const card = page.getByTestId('user-card');
    await card.getByRole('button', { name: 'Follow' }).click();

    await expect(card.getByRole('button', { name: 'Unfollow' })).toBeVisible();
    await expect(card.locator('.status')).toHaveText('Following');
  });

  test('XPath does NOT pierce shadow DOM', async ({ page }) => {
    await page.goto('/shadow.html');
    await expect(page.locator('//button[text()="Follow"]')).toHaveCount(0);
    await expect(page.locator('button.follow')).toHaveCount(1); // CSS works
  });
});
