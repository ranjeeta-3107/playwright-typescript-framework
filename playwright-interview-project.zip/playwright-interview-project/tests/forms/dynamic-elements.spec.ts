import { test, expect } from '@playwright/test';

/**
 * MODULE 6 – DYNAMIC ELEMENTS AND DYNAMIC LISTS
 */

test.beforeEach(async ({ page }) => {
  await page.goto('/dynamic.html');
});

test('add and remove items in a dynamic list', async ({ page }) => {
  const tasks = page.getByRole('list', { name: 'Tasks' }).getByRole('listitem');

  await page.getByLabel('New task').fill('Learn fixtures');
  await page.getByRole('button', { name: 'Add task' }).click();
  await page.getByLabel('New task').fill('Learn POM');
  await page.getByRole('button', { name: 'Add task' }).click();

  // toHaveText with an array checks every item in order.
  await expect(tasks).toHaveText([/Write tests/, /Review PR/, /Learn fixtures/, /Learn POM/]);

  await tasks.filter({ hasText: 'Write tests' }).getByRole('button', { name: 'Remove' }).click();
  await expect(tasks).toHaveCount(3);
  await expect(tasks.first()).toContainText('Review PR');
});

test('content that loads after a network call', async ({ page }) => {
  await page.getByRole('button', { name: 'Load products' }).click();

  const products = page.getByRole('list', { name: 'Product list' }).getByRole('listitem');
  // Other tests may add products in parallel, so check that seeded items exist rather than an exact count.
  await expect(products.filter({ hasText: 'Laptop - $999' })).toHaveCount(1);
  await expect(products.filter({ hasText: 'Notebook - $5' })).toHaveCount(1);
});

test('element with a random id – locate by role and name instead', async ({ page }) => {
  const button = page.getByRole('button', { name: 'Dynamic ID button' });
  await expect(button).toHaveAttribute('id', /^btn-[a-z0-9]+$/); // id is different on every load
  await button.click();
  await expect(page.getByTestId('dynamic-id-result')).toHaveText('Clicked dynamic button');
});
