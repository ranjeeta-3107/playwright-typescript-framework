import { test, expect, type Page } from '@playwright/test';
import { validRegistration, type RegistrationData } from '../../utils/test-data';

/**
 * MODULE 6 – FORMS: text boxes, password fields, radios, checkboxes,
 * dropdowns, date pickers and form validation.
 */

/** Small helper: fill the whole form. A plain function is often enough – no class needed. */
async function fillRegistrationForm(page: Page, data: RegistrationData): Promise<void> {
  await page.getByLabel('Full name').fill(data.fullName);
  await page.getByLabel('Email').fill(data.email);
  await page.getByLabel('Password').fill(data.password);
  await page.getByRole('radio', { name: data.gender, exact: true }).check();
  await page.getByLabel('Country').selectOption({ label: data.country });
}

test.beforeEach(async ({ page }) => {
  await page.goto('/forms.html');
});

test('submit a complete registration form', async ({ page }) => {
  await fillRegistrationForm(page, validRegistration);
  await page.getByRole('checkbox', { name: 'Reading' }).check();
  await page.getByRole('checkbox', { name: 'Music' }).check();
  await page.getByLabel('Skills').selectOption(['playwright', 'api']);
  await page.getByLabel('Date of birth').fill('1998-05-21'); // native date inputs take yyyy-mm-dd
  await page.getByLabel('Bio').fill('QA engineer learning Playwright');

  await page.getByLabel('I accept the terms and conditions').check();
  await page.getByRole('button', { name: 'Register' }).click();

  await expect(page.getByTestId('success-message')).toHaveText(`Registration successful for ${validRegistration.fullName}`);
});

test('password field masks the typed value', async ({ page }) => {
  const password = page.getByLabel('Password');
  await password.fill('SuperSecret1');

  await expect(password).toHaveAttribute('type', 'password');
  await expect(password).toHaveValue('SuperSecret1'); // the value is still readable by the test
});

test('Register button is disabled until the terms are accepted', async ({ page }) => {
  const register = page.getByRole('button', { name: 'Register' });
  const terms = page.getByLabel('I accept the terms and conditions');

  await expect(register).toBeDisabled();
  await terms.check();
  await expect(register).toBeEnabled();
  await terms.uncheck();
  await expect(register).toBeDisabled();
});

test.describe('form validation', () => {
  test('empty form shows all required-field errors', async ({ page }) => {
    await page.getByLabel('I accept the terms and conditions').check();
    await page.getByRole('button', { name: 'Register' }).click();

    await expect(page.locator('#fullName-error')).toHaveText('Full name is required');
    await expect(page.locator('#email-error')).toHaveText('Enter a valid email address');
    await expect(page.locator('#password-error')).toHaveText('Password must be at least 8 characters');
    await expect(page.locator('#gender-error')).toHaveText('Please select a gender');
    await expect(page.locator('#country-error')).toHaveText('Please select a country');
    await expect(page.getByTestId('success-message')).toBeEmpty();
  });

  // Data-driven validation: one test per invalid email.
  for (const email of ['plainaddress', 'missing-at.com', 'user@', 'user@domain']) {
    test(`invalid email "${email}" is rejected`, async ({ page }) => {
      await fillRegistrationForm(page, { ...validRegistration, email });
      await page.getByLabel('I accept the terms and conditions').check();
      await page.getByRole('button', { name: 'Register' }).click();

      await expect(page.locator('#email-error')).toHaveText('Enter a valid email address');
    });
  }

  test('bio character counter updates while typing', async ({ page }) => {
    await page.getByLabel('Bio').fill('Hello');
    await expect(page.getByTestId('bio-counter')).toHaveText('5/200');
  });

  test('Reset button clears the form', async ({ page }) => {
    await fillRegistrationForm(page, validRegistration);
    await page.getByRole('button', { name: 'Reset' }).click();

    await expect(page.getByLabel('Full name')).toHaveValue('');
    await expect(page.getByLabel('Country')).toHaveValue('');
  });
});

test.describe('date pickers', () => {
  test('native <input type="date"> – just fill() with yyyy-mm-dd', async ({ page }) => {
    await page.getByLabel('Date of birth').fill('2000-01-31');
    await expect(page.getByLabel('Date of birth')).toHaveValue('2000-01-31');
  });

  test('custom calendar widget – navigate to next month and pick a day', async ({ page }) => {
    // Calculate the expected month dynamically – never hard-code "today" in tests.
    const target = new Date();
    target.setDate(1);
    target.setMonth(target.getMonth() + 1);
    const monthName = target.toLocaleString('en-US', { month: 'long' });
    const expected = `${target.getFullYear()}-${String(target.getMonth() + 1).padStart(2, '0')}-15`;

    await page.getByRole('button', { name: 'Open calendar' }).click();
    const calendar = page.getByRole('dialog', { name: 'Choose joining date' });
    await calendar.getByRole('button', { name: 'Next month' }).click();
    await expect(calendar.getByTestId('calendar-month')).toHaveText(`${monthName} ${target.getFullYear()}`);

    await calendar.getByRole('gridcell', { name: '15', exact: true }).click();

    // getByLabel('Joining date') would be ambiguous here: it also matches the calendar's
    // aria-label "Choose joining date" (substring match). getByRole + name is precise.
    await expect(page.getByRole('textbox', { name: 'Joining date' })).toHaveValue(expected);
    await expect(calendar).toBeHidden();
  });
});
