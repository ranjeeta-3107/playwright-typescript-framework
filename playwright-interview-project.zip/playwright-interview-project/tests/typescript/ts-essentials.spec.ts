import { test, expect, type Locator, type Page } from '@playwright/test';
// Imports: named imports with { } and type-only imports with `type`.
import { buildProduct, type Product } from '../../utils/test-data';

/**
 * MODULE 16 – TYPESCRIPT ESSENTIALS FOR PLAYWRIGHT
 *
 * Only the TypeScript you actually need to write Playwright tests.
 * Most tests here don't use a browser – they just show the language feature.
 */

test.describe('variables, data types and type annotations', () => {
  test('const, let and basic types', () => {
    const baseUrl: string = 'http://localhost:3000'; // const: cannot be re-assigned (use by default)
    let retries: number = 0; // let: value will change
    retries++;
    const headless: boolean = true;
    const tags: string[] = ['@smoke', '@regression']; // array of strings
    const viewport: { width: number; height: number } = { width: 1280, height: 720 }; // object type
    let maybeToken: string | undefined; // union type: string OR undefined

    expect(baseUrl.startsWith('http')).toBe(true);
    expect(retries).toBe(1);
    expect(headless).toBe(true);
    expect(tags).toHaveLength(2);
    expect(viewport.width).toBe(1280);
    expect(maybeToken).toBeUndefined();

    // Type inference: TypeScript already knows `count` is a number.
    const count = tags.length;
    expect(typeof count).toBe('number');
  });

  test('template literals and optional chaining / nullish coalescing', () => {
    const user = { name: 'Asha', address: undefined as { city: string } | undefined };
    const greeting = `Welcome, ${user.name}`; // template literal
    const city = user.address?.city ?? 'Unknown'; // ?. stops on undefined, ?? gives a default

    expect(greeting).toBe('Welcome, Asha');
    expect(city).toBe('Unknown');
  });
});

test.describe('functions', () => {
  // Typed parameters + return type + default parameter value
  function formatPrice(amount: number, currency: string = '$'): string {
    return `${currency}${amount}`;
  }
  // Arrow function with an optional parameter (?)
  const fullName = (first: string, last?: string): string => (last ? `${first} ${last}` : first);

  test('typed functions, default and optional parameters', () => {
    expect(formatPrice(999)).toBe('$999');
    expect(formatPrice(50, '₹')).toBe('₹50');
    expect(fullName('Ravi')).toBe('Ravi');
    expect(fullName('Ravi', 'Kumar')).toBe('Ravi Kumar');
  });
});

test.describe('arrays and objects', () => {
  test('map, filter, find, destructuring and spread', () => {
    const products: Product[] = [
      { name: 'Laptop', category: 'Electronics', price: 999 },
      { name: 'Mug', category: 'Kitchen', price: 12 },
    ];

    const names = products.map((p) => p.name);
    const cheap = products.filter((p) => p.price < 100);
    const laptop = products.find((p) => p.name === 'Laptop');
    const { name, price } = products[1]; // object destructuring
    const [first] = products; // array destructuring
    const updated = { ...first, price: 899 }; // spread: copy + override

    expect(names).toEqual(['Laptop', 'Mug']);
    expect(cheap).toHaveLength(1);
    expect(laptop?.price).toBe(999);
    expect(`${name}:${price}`).toBe('Mug:12');
    expect(updated.price).toBe(899);
    expect(first.price).toBe(999); // original unchanged
  });
});

test.describe('interfaces and types', () => {
  // interface: describes the shape of an object (good for data and classes)
  interface Credentials {
    username: string;
    password: string;
    rememberMe?: boolean; // optional property
  }
  // type alias: can also describe unions / literal types
  type Browser = 'chromium' | 'firefox' | 'webkit';
  type ApiResult<T> = { status: number; body: T }; // generic type

  test('use interfaces, unions and generics to catch mistakes early', () => {
    const creds: Credentials = { username: 'student', password: 'from-env-in-real-tests' };
    const browser: Browser = 'firefox'; // 'safari' would be a compile-time error
    const result: ApiResult<Product> = { status: 201, body: buildProduct({ price: 10 }) };

    expect(creds.rememberMe).toBeUndefined();
    expect(browser).toBe('firefox');
    expect(result.body.price).toBe(10);
  });
});

test.describe('classes, constructors and access modifiers', () => {
  class BasePage {
    // protected: visible to this class and subclasses, not to tests
    constructor(protected readonly page: Page) {}

    async open(path: string): Promise<void> {
      await this.page.goto(path);
    }
  }

  class AlertsPage extends BasePage {
    // public (default): usable from tests; readonly: cannot be re-assigned
    public readonly result: Locator;
    // private: only usable inside this class
    private readonly path = '/alerts.html';

    constructor(page: Page) {
      super(page); // call the parent constructor first
      this.result = page.getByTestId('dialog-result');
    }

    async goto(): Promise<void> {
      await this.open(this.path);
    }

    async confirm(accept: boolean): Promise<void> {
      this.page.once('dialog', (dialog) => (accept ? dialog.accept() : dialog.dismiss()));
      await this.page.getByRole('button', { name: 'Show confirm' }).click();
    }
  }

  test('inheritance and access modifiers in a page object', async ({ page }) => {
    const alertsPage = new AlertsPage(page);
    await alertsPage.goto();
    await alertsPage.confirm(true);
    await expect(alertsPage.result).toHaveText('Confirm: OK');
    // alertsPage.path  → compile error: 'path' is private
  });
});

test.describe('promises, async/await and exception handling', () => {
  const wait = (ms: number): Promise<string> => new Promise((resolve) => setTimeout(() => resolve(`waited ${ms}`), ms));

  test('await a promise; run independent promises in parallel with Promise.all', async ({ page }) => {
    expect(await wait(10)).toBe('waited 10');

    // Classic pattern: start waiting for an event and trigger it at the same time.
    await page.goto('/windows.html');
    const [popup] = await Promise.all([
      page.waitForEvent('popup'),
      page.getByRole('link', { name: 'Open new tab' }).click(),
    ]);
    await expect(popup).toHaveTitle(/New Tab/);
  });

  test('forgetting `await` is the #1 beginner bug', async ({ page }) => {
    await page.goto('/');
    // ❌ expect(page).toHaveTitle('x')  → not awaited: the test may finish before it is checked
    // ✅ await expect(page).toHaveTitle(...)
    await expect(page).toHaveTitle(/Home/);
  });

  test('try / catch / finally', async ({ request }) => {
    let cleanedUp = false;
    try {
      const response = await request.get('/api/products/123456');
      if (!response.ok()) {
        throw new Error(`Request failed with status ${response.status()}`);
      }
    } catch (error) {
      // `error` is `unknown` in TypeScript – narrow it before use
      expect(error instanceof Error ? error.message : String(error)).toBe('Request failed with status 404');
    } finally {
      cleanedUp = true; // always runs: the place for cleanup
    }
    expect(cleanedUp).toBe(true);
  });
});
