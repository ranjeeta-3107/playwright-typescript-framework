import { test, expect, type APIRequestContext } from '@playwright/test';
import { users } from '../../utils/test-data';
import { getBaseUrl } from '../../utils/env';

/**
 * MODULE 8 – HOOKS
 *
 *   beforeAll  – once per WORKER before the tests of this file/describe (no `page` available)
 *   beforeEach – before EVERY test (gets the same fixtures as the test: page, context, ...)
 *   afterEach  – after EVERY test, even when it failed (cleanup, extra logging)
 *   afterAll   – once per worker after the tests (release what beforeAll created)
 *
 * Important: with fullyParallel, tests of one file can run in DIFFERENT workers, and each
 * worker runs beforeAll/afterAll on its own. Never rely on beforeAll running exactly once.
 */

test.describe('hook lifecycle', () => {
  let api: APIRequestContext; // shared by the tests of this describe (within one worker)
  const log: string[] = [];

  test.beforeAll(async ({ playwright }) => {
    // Worker-level setup: create an API client once and log in.
    // beforeAll only receives WORKER fixtures (browser, playwright), not page or baseURL.
    api = await playwright.request.newContext({ baseURL: getBaseUrl() });
    const response = await api.post('/api/login', { data: users.standard });
    expect(response.ok()).toBeTruthy();
    log.push('beforeAll');
  });

  test.beforeEach(async ({ page }, testInfo) => {
    log.push(`beforeEach: ${testInfo.title}`);
    await page.goto('/');
  });

  test.afterEach(async ({ page }, testInfo) => {
    log.push(`afterEach: ${testInfo.title} → ${testInfo.status}`);
    // A typical real-world use: extra evidence when a test fails.
    if (testInfo.status !== testInfo.expectedStatus) {
      await testInfo.attach('url-at-failure', { body: page.url(), contentType: 'text/plain' });
    }
  });

  test.afterAll(async () => {
    log.push('afterAll');
    await api.dispose(); // release resources created in beforeAll
  });

  test('beforeEach already opened the home page', async ({ page }) => {
    await expect(page).toHaveTitle(/Home/);
    expect(log[0]).toBe('beforeAll');
  });

  test('the API client created in beforeAll is reusable', async () => {
    // The session cookie from the login above is stored inside the request context.
    const me = await api.get('/api/me');
    expect(me.status()).toBe(200);
    expect((await me.json()).username).toBe(users.standard.username);
  });
});

test.describe('outer group', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/forms.html'); // runs first for every test in this group (and nested groups)
  });

  test('outer test', async ({ page }) => {
    await expect(page).toHaveURL(/forms/);
  });

  test.describe('nested group', () => {
    test.beforeEach(async ({ page }) => {
      // Runs AFTER the outer beforeEach – hooks run from outside to inside.
      await page.getByLabel('Full name').fill('From nested hook');
    });

    test('nested test sees the effect of both hooks', async ({ page }) => {
      await expect(page).toHaveURL(/forms/);
      await expect(page.getByLabel('Full name')).toHaveValue('From nested hook');
    });
  });
});
