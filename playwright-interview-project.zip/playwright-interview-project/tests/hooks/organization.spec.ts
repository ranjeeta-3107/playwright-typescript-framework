import { test, expect, type Page } from '@playwright/test';

/**
 * MODULE 8 – TEST ORGANISATION: tags, filtering, annotations, retries,
 * parallel and serial execution.
 *
 * Filtering from the terminal:
 *   npx playwright test --grep @smoke                 # only tagged tests
 *   npx playwright test --grep-invert @slow           # everything except @slow
 *   npx playwright test --grep "@smoke|@regression"   # either tag
 *   npx playwright test -g "checkout"                 # title contains "checkout"
 */

test.describe('tagging', { tag: '@regression' }, () => {
  // Tags on a describe apply to every test inside it.
  test('regression test with an extra @smoke tag', { tag: '@smoke' }, async ({ page }) => {
    await page.goto('/table.html');
    await expect(page.getByRole('table', { name: 'Employees' })).toBeVisible();
  });

  test('test with an annotation (shown in the HTML report)', {
    annotation: { type: 'issue', description: 'https://example.com/issues/123' },
  }, async ({ page }) => {
    await page.goto('/alerts.html');
    await expect(page.getByRole('heading', { name: 'JavaScript dialogs' })).toBeVisible();
  });
});

test.describe('parallel mode', () => {
  // Default in this project (fullyParallel: true): tests may run in any order, in different workers.
  // That only works because every test is INDEPENDENT – it does its own setup.
  test.describe.configure({ mode: 'parallel' });

  test('independent test A – creates its own state', async ({ page }) => {
    await page.goto('/dynamic.html');
    await page.getByLabel('New task').fill('Task A');
    await page.getByRole('button', { name: 'Add task' }).click();
    await expect(page.getByRole('listitem').filter({ hasText: 'Task A' })).toBeVisible();
  });

  test('independent test B – does not depend on test A', async ({ page }) => {
    await page.goto('/dynamic.html');
    // Fresh page: Task A from the other test does NOT exist here.
    await expect(page.getByRole('listitem').filter({ hasText: 'Task A' })).toHaveCount(0);
  });
});

/**
 * SERIAL MODE – tests run one after another in the same worker and SHARE a page.
 * Limitations (why it is usually avoided):
 *   - If one test fails, the remaining tests in the group are SKIPPED.
 *   - On retry, the WHOLE group is retried together.
 *   - Tests can't be run on their own (test 2 needs test 1) and can't run in parallel.
 * Use only for genuinely step-by-step flows that cannot be split up.
 */
test.describe('serial mode (dependent steps)', () => {
  test.describe.configure({ mode: 'serial' });

  let page: Page;

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
  });

  test.afterAll(async () => {
    await page.close();
  });

  test('step 1 – add a task', async () => {
    await page.goto('/dynamic.html');
    await page.getByLabel('New task').fill('Serial task');
    await page.getByRole('button', { name: 'Add task' }).click();
    await expect(page.getByRole('listitem').filter({ hasText: 'Serial task' })).toBeVisible();
  });

  test('step 2 – the task from step 1 is still there (shared page)', async () => {
    await expect(page.getByRole('listitem').filter({ hasText: 'Serial task' })).toBeVisible();
    await page.getByRole('listitem').filter({ hasText: 'Serial task' }).getByRole('button', { name: 'Remove' }).click();
    await expect(page.getByRole('listitem').filter({ hasText: 'Serial task' })).toHaveCount(0);
  });
});

test.describe('retries', () => {
  // Retries for this group only (globally: `retries` in the config or `--retries=2`).
  test.describe.configure({ retries: 2 });

  test('testInfo.retry tells you which attempt this is', async ({ page }, testInfo) => {
    // Attempt numbers: 0 = first run, 1 = first retry, ...
    // A test that fails and then passes on retry is reported as "flaky".
    if (testInfo.retry > 0) {
      // e.g. clear server-side state that the failed attempt may have left behind
      console.log(`Retry #${testInfo.retry}`);
    }
    await page.goto('/');
    await expect(page).toHaveTitle(/Home/);
  });
});
