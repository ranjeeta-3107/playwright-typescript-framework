import { test, expect } from '@playwright/test';

/**
 * MODULE 9 – BUILT-IN FIXTURES
 *
 * Test-scoped (new for every test):
 *   page     – a fresh tab in a fresh context
 *   context  – the BrowserContext that owns `page`
 *   request  – an APIRequestContext for API calls (uses baseURL, independent of the page)
 * Worker-scoped (shared by all tests in one worker process):
 *   browser  – the browser instance
 *   playwright – the Playwright library object (e.g. playwright.request.newContext)
 * Option fixtures: baseURL, browserName, viewport, storageState, ... (set with test.use / config)
 * Plus the second argument of every test: testInfo (title, retry, outputPath, attach...).
 */

test('page and context', async ({ page, context }) => {
  await page.goto('/');
  expect(page.context()).toBe(context); // `page` belongs to `context`
  expect(context.pages()).toContain(page);
});

test('browser – create extra contexts yourself', async ({ browser, browserName }) => {
  const context = await browser.newContext({ viewport: { width: 400, height: 800 } });
  const page = await context.newPage();
  await page.goto('/advanced.html');
  await expect(page.getByTestId('layout')).toHaveText('Mobile layout');
  expect(['chromium', 'firefox', 'webkit']).toContain(browserName);
  await context.close();
});

test('request – call an API without opening a browser page', async ({ request }) => {
  const response = await request.get('/api/products/1');
  expect(response.ok()).toBeTruthy();
  expect(await response.json()).toMatchObject({ id: 1, name: 'Laptop' });
});

test('baseURL and testInfo', async ({ baseURL }, testInfo) => {
  expect(baseURL).toMatch(/^https?:\/\//);
  expect(testInfo.title).toBe('baseURL and testInfo');
  expect(testInfo.project.name).toBeTruthy(); // chromium / firefox / webkit
});

test.describe('overriding option fixtures with test.use()', () => {
  // Applies to every test in this describe block.
  test.use({ viewport: { width: 375, height: 667 }, locale: 'en-IN' });

  test('small viewport shows the mobile layout', async ({ page }) => {
    await page.goto('/advanced.html');
    await expect(page.getByTestId('viewport-size')).toHaveText('Viewport: 375x667');
    expect(await page.evaluate(() => navigator.language)).toBe('en-IN');
  });
});
