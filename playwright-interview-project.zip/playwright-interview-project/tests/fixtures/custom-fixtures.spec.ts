// Import `test` and `expect` from OUR fixtures file instead of '@playwright/test'.
import { test, expect } from '../../fixtures/test-fixtures';
import { STORAGE_STATE } from '../../utils/test-data';

/**
 * MODULE 9 – CUSTOM FIXTURES (defined in fixtures/test-fixtures.ts)
 *
 * Compared with beforeEach hooks, fixtures are:
 *   - reusable across files (import once, use anywhere)
 *   - on-demand (only created when a test asks for them)
 *   - self-cleaning (teardown code lives next to the setup code)
 *   - composable (a fixture can use other fixtures: testProduct → api → apiToken)
 */

test('page object fixture – no "new LoginPage(page)" needed', async ({ loginPage, page }) => {
  await loginPage.goto();
  await expect(loginPage.loginButton).toBeVisible();
  await expect(page).toHaveTitle(/Login/);
});

test('authenticated API fixture', async ({ api }) => {
  const response = await api.get('/api/me');
  expect(response.status()).toBe(200);
});

test('data fixture – a product is created before and deleted after the test', async ({ testProduct, request }) => {
  // The product exists while the test runs:
  const response = await request.get(`/api/products/${testProduct.id}`);
  expect(response.status()).toBe(200);
  expect(await response.json()).toMatchObject({ name: testProduct.name, category: 'Test Data' });
  // ...and the fixture's teardown deletes it after the test finishes.
});

test.describe('fixtures + storageState', () => {
  test.use({ storageState: STORAGE_STATE });

  test('dashboard shows the product created by the fixture', async ({ dashboardPage, testProduct }) => {
    await dashboardPage.goto();
    await dashboardPage.search(testProduct.name);
    await expect(dashboardPage.rowFor(testProduct.name)).toContainText('Test Data');
  });
});
