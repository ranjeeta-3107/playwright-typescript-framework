import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { DashboardPage } from '../../pages/DashboardPage';
import { displayNames, users } from '../../utils/test-data';

/**
 * MODULE 10 – PAGE OBJECT MODEL (POM)
 *
 * Tests read like user stories; the "how" (locators, clicks) lives in pages/*.ts.
 * Compare this file with tests/authentication/login-logout.spec.ts, which uses the
 * same page objects through fixtures instead of `new`.
 */

test.describe('login with page objects', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
    await loginPage.goto();
  });

  test('valid user reaches the dashboard', async () => {
    await loginPage.login(users.standard.username, users.standard.password);
    await dashboardPage.expectLoggedInAs(displayNames.standard);
  });

  test('admin user reaches the dashboard', async () => {
    await loginPage.login(users.admin.username, users.admin.password);
    await dashboardPage.expectLoggedInAs(displayNames.admin);
  });

  test('wrong password shows an error and stays on the login page', async ({ page }) => {
    await loginPage.login(users.standard.username, 'not-the-password');
    await loginPage.expectErrorMessage('Invalid username or password');
    await expect(page).toHaveURL(/login/);
  });

  test('user can log out', async () => {
    await loginPage.login(users.standard.username, users.standard.password);
    await dashboardPage.expectLoggedInAs(displayNames.standard);

    await dashboardPage.logout();
    await expect(loginPage.logoutMessage).toBeVisible();
  });
});
