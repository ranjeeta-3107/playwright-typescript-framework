import { test, expect } from '../../fixtures/test-fixtures';
import { STORAGE_STATE } from '../../utils/test-data';

/**
 * MODULE 10 – POM + FIXTURES + storageState: search, filter and table handling
 * on the dashboard. The page object is injected by the `dashboardPage` fixture
 * and the user is already logged in thanks to storageState.
 */

test.use({ storageState: STORAGE_STATE });

test.beforeEach(async ({ dashboardPage }) => {
  await dashboardPage.goto();
  await expect(dashboardPage.heading).toBeVisible();
});

test('search filters the product table', async ({ dashboardPage }) => {
  await dashboardPage.search('Lap');

  await expect(dashboardPage.productRows).toHaveCount(1);
  await expect(dashboardPage.rowFor('Laptop')).toContainText('$999');
});

test('search with no matches shows an empty table', async ({ dashboardPage }) => {
  await dashboardPage.search('does-not-exist');

  await expect(dashboardPage.productRows).toHaveCount(0);
  await expect(dashboardPage.productCount).toHaveText('Showing 0 product(s)');
});

test('filter by category', async ({ dashboardPage }) => {
  await dashboardPage.filterByCategory('Electronics');

  // Read the "Category" column of every row and check they are all Electronics.
  const categories = dashboardPage.productRows.locator('td:nth-child(2)');
  await expect(categories).toHaveText(['Electronics', 'Electronics', 'Electronics']);
  await expect(dashboardPage.rowFor('Keyboard')).toContainText('Out of stock');
});

test('combine search and category filters', async ({ dashboardPage }) => {
  await dashboardPage.filterByCategory('Kitchen');
  await dashboardPage.search('Mug');

  await expect(dashboardPage.productRows).toHaveCount(1);
  await expect(dashboardPage.productRows.first().getByRole('cell').first()).toHaveText('Coffee Mug');
});

/*
 * POM – advantages: one place to update locators, readable tests, reusable actions.
 * POM – disadvantages: extra code to maintain; over-abstracted "god" page objects
 *       hide what a test does; not worth it for a handful of tiny tests.
 * Rule of thumb: introduce page objects when the same page is used by several tests.
 */
