import { test, expect } from '@playwright/test';
import { requireEnv } from '../../utils/test-data';

/**
 * OPTIONAL – TESTS AGAINST A PUBLIC DEMO SITE (https://www.saucedemo.com)
 *
 * Shows that the same techniques work on a real remote site. These tests:
 *   - need internet access, and the site must be up,
 *   - run only when you select the project:   npm run test:public
 *     (equivalent: npx playwright test --project=public-demo)
 *   - use the site's public practice account from SAUCE_USERNAME / SAUCE_PASSWORD (.env).
 *
 * NOTE: the bundled local app is the main practice target because public sites can change,
 * slow down or go offline. If these fail, check the site in a browser first.
 * (These tests could not be executed in the environment where this project was built.)
 */

test.beforeEach(async ({ page }) => {
  await page.goto('/');
});

test('login with the public standard user', async ({ page }) => {
  await page.getByPlaceholder('Username').fill(requireEnv('SAUCE_USERNAME'));
  await page.getByPlaceholder('Password').fill(requireEnv('SAUCE_PASSWORD'));
  await page.getByRole('button', { name: 'Login' }).click();

  await expect(page).toHaveURL(/inventory\.html/);
  await expect(page.getByText('Products')).toBeVisible();
});

test('wrong password shows an error', async ({ page }) => {
  await page.getByPlaceholder('Username').fill(requireEnv('SAUCE_USERNAME'));
  await page.getByPlaceholder('Password').fill('wrong-password');
  await page.getByRole('button', { name: 'Login' }).click();

  // testIdAttribute is 'data-test' for this project (see playwright.config.ts).
  await expect(page.getByTestId('error')).toContainText('do not match');
});

test('sort products by price (low to high)', async ({ page }) => {
  await page.getByPlaceholder('Username').fill(requireEnv('SAUCE_USERNAME'));
  await page.getByPlaceholder('Password').fill(requireEnv('SAUCE_PASSWORD'));
  await page.getByRole('button', { name: 'Login' }).click();
  await expect(page).toHaveURL(/inventory\.html/);

  await page.locator('select').selectOption('lohi');
  const prices = (await page.getByTestId('inventory-item-price').allTextContents()).map((p) =>
    Number(p.replace('$', '')),
  );
  expect(prices.length).toBeGreaterThan(0);
  expect(prices).toEqual([...prices].sort((a, b) => a - b));
});
