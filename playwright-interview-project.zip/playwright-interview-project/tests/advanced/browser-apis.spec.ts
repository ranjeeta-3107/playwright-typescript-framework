import { test, expect } from '@playwright/test';

/**
 * MODULE 14 – ADVANCED BROWSER APIS
 */

test.describe('evaluate() – run JavaScript inside the browser', () => {
  test('return values from the page', async ({ page }) => {
    await page.goto('/');

    // The function runs IN THE BROWSER – it cannot see test variables unless passed as an argument.
    const title = await page.evaluate(() => document.title);
    expect(title).toBe('Practice App | Home');

    // Pass arguments (must be serialisable: strings, numbers, plain objects...)
    const sum = await page.evaluate(([a, b]) => a + b, [2, 3]);
    expect(sum).toBe(5);
  });

  test('locator.evaluate() and evaluateAll()', async ({ page }) => {
    await page.goto('/forms.html');

    const tagName = await page.getByLabel('Country').evaluate((el) => el.tagName);
    expect(tagName).toBe('SELECT');

    const optionValues = await page.locator('#country option').evaluateAll(
      (options) => options.map((o) => (o as HTMLOptionElement).value),
    );
    expect(optionValues).toEqual(['', 'in', 'us', 'uk', 'de']);
  });

  test('browser storage: sessionStorage and localStorage', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => {
      sessionStorage.setItem('cart', JSON.stringify(['laptop']));
      localStorage.setItem('theme', 'dark');
    });

    const cart = await page.evaluate(() => JSON.parse(sessionStorage.getItem('cart') ?? '[]'));
    expect(cart).toEqual(['laptop']);

    await page.reload();
    await expect(page.getByTestId('theme-status')).toHaveText('Current theme: dark');
  });
});

test.describe('setting up the page before it loads', () => {
  test('addInitScript() runs before any page script (feature flags, mocks of Date, etc.)', async ({ page }) => {
    await page.addInitScript(() => {
      (window as unknown as { __FEATURE_FLAGS__: { beta: boolean } }).__FEATURE_FLAGS__ = { beta: true };
    });
    await page.goto('/advanced.html');
    await expect(page.getByTestId('beta-banner')).toHaveText('Beta features are enabled');
  });

  test('addInitScript() can pre-fill localStorage', async ({ page }) => {
    await page.addInitScript(() => localStorage.setItem('theme', 'dark'));
    await page.goto('/');
    await expect(page.getByTestId('theme-status')).toHaveText('Current theme: dark');
  });

  test('setExtraHTTPHeaders() adds headers to every request of the page', async ({ page }) => {
    await page.setExtraHTTPHeaders({ 'X-Test-Run': 'nightly-42' });
    await page.goto('/advanced.html');
    await page.getByRole('button', { name: 'Check request headers' }).click();
    await expect(page.getByTestId('headers-result')).toHaveText('x-test-run: nightly-42');
  });

  test('setViewportSize() – switch between desktop and mobile layouts', async ({ page }) => {
    await page.goto('/advanced.html');

    await page.setViewportSize({ width: 1280, height: 720 });
    await expect(page.getByTestId('layout')).toHaveText('Desktop layout');

    await page.setViewportSize({ width: 390, height: 844 });
    await expect(page.getByTestId('layout')).toHaveText('Mobile layout');
    await expect(page.getByTestId('viewport-size')).toHaveText('Viewport: 390x844');
  });
});

test.describe('geolocation and permissions', () => {
  // Fake location (Pune, India) and grant the permission for this group.
  test.use({ geolocation: { latitude: 18.5204, longitude: 73.8567 }, permissions: ['geolocation'] });

  test('page reads the mocked location', async ({ page }) => {
    await page.goto('/advanced.html');
    await page.getByRole('button', { name: 'Get my location' }).click();
    await expect(page.getByTestId('location')).toHaveText('Latitude: 18.52, Longitude: 73.86');
  });

  test('change location during a test', async ({ page, context }) => {
    await context.setGeolocation({ latitude: 51.5072, longitude: -0.1276 }); // London
    await page.goto('/advanced.html');
    await page.getByRole('button', { name: 'Get my location' }).click();
    await expect(page.getByTestId('location')).toHaveText('Latitude: 51.51, Longitude: -0.13');
  });
});

test.describe('low-level keyboard and mouse', () => {
  test('page.keyboard – type, press, hold modifier keys', async ({ page }) => {
    await page.goto('/elements.html');
    await page.getByLabel('Key logger').focus();

    await page.keyboard.type('Hello');
    await expect(page.getByLabel('Key logger')).toHaveValue('Hello');

    await page.keyboard.down('Shift');
    await page.keyboard.press('ArrowLeft'); // select one character while Shift is held
    await page.keyboard.up('Shift');
    await expect(page.getByTestId('last-key')).toHaveText('Last key: Shift+ArrowLeft');

    await page.keyboard.press('Backspace'); // deletes the selected "o"
    await expect(page.getByLabel('Key logger')).toHaveValue('Hell');
  });

  test('page.mouse – move to coordinates and click', async ({ page }) => {
    await page.goto('/elements.html');
    const area = page.getByTestId('mouse-area');
    const box = await area.boundingBox();
    if (!box) throw new Error('mouse area is not visible');

    await page.mouse.move(box.x + 30, box.y + 40);
    await expect(page.getByTestId('mouse-position')).toHaveText('Mouse at 30,40');

    // Manual drag: down → move → up (what dragTo() does for you)
    await page.mouse.down();
    await page.mouse.move(box.x + 60, box.y + 50, { steps: 5 });
    await page.mouse.up();
    await expect(page.getByTestId('mouse-position')).toHaveText('Mouse at 60,50');
  });

  test('mouse wheel scrolling', async ({ page }) => {
    await page.goto('/elements.html');
    await page.mouse.wheel(0, 600);
    await expect.poll(() => page.evaluate(() => window.scrollY)).toBeGreaterThan(0);
  });
});
