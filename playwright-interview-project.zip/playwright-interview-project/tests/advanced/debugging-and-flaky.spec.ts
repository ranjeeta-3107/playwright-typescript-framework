import fs from 'node:fs';
import { test, expect } from '@playwright/test';

/**
 * MODULE 14 – DEBUGGING, TRACES, VIDEOS, ANNOTATIONS, CONDITIONAL & FLAKY TESTS
 *
 * Debugging toolbox (see README "How to debug tests"):
 *   npx playwright test --debug          → Playwright Inspector, step through actions
 *   npx playwright test --ui             → UI mode: time-travel through every step
 *   npx playwright test --headed         → watch the browser
 *   PWDEBUG=1 npx playwright test        → same as --debug
 *   npx playwright show-trace <trace.zip> → Trace Viewer
 *   await page.pause()                   → pause at a specific line (only in headed/debug mode)
 */

test('page.pause() – stop at this line and open the Inspector', async ({ page }) => {
  // page.pause() would block forever in normal headless runs, so it only runs when debugging:
  //   PWDEBUG=1 npx playwright test debugging-and-flaky.spec.ts -g "page.pause"
  test.skip(!process.env.PWDEBUG, 'Only meaningful when debugging (set PWDEBUG=1)');

  await page.goto('/forms.html');
  await page.pause(); // Inspector opens here – try locators in its "Pick locator" tool
  await page.getByLabel('Full name').fill('Debugged!');
});

test('test.step() – group actions so reports and traces are easy to read', async ({ page }) => {
  await test.step('open the form', async () => {
    await page.goto('/forms.html');
  });
  await test.step('fill the name', async () => {
    await page.getByLabel('Full name').fill('Step by step');
  });
  await test.step('verify', async () => {
    await expect(page.getByLabel('Full name')).toHaveValue('Step by step');
  });
});

test('record a trace manually and open it with the Trace Viewer', async ({ browser }, testInfo) => {
  // Normally the config does this for you (trace: 'on-first-retry'). On a retry the runner
  // is already tracing every context, so we skip this manual demo then.
  test.skip(testInfo.retry > 0, 'Tracing is already started by the runner on retries');

  const context = await browser.newContext();
  await context.tracing.start({ screenshots: true, snapshots: true, sources: true });
  const page = await context.newPage();
  await page.goto('/elements.html');
  await page.getByRole('button', { name: 'Click me', exact: true }).click();

  const tracePath = testInfo.outputPath('manual-trace.zip');
  await context.tracing.stop({ path: tracePath });
  await context.close();

  expect(fs.existsSync(tracePath)).toBe(true);
  // Open it with:  npx playwright show-trace test-results/<this test folder>/manual-trace.zip
});

test('record a video manually with recordVideo', async ({ browser }, testInfo) => {
  // Normally the config does this (video: 'retain-on-failure' / 'on'). Note: `video` is a
  // worker-level option, so `test.use({ video: 'on' })` is only allowed at the top of a file.
  const context = await browser.newContext({ recordVideo: { dir: testInfo.outputPath('videos') } });
  const page = await context.newPage();
  await page.goto('/table.html');
  await page.getByRole('button', { name: 'Next' }).click();
  await expect(page.getByTestId('page-info')).toHaveText('Page 2 of 5');

  const video = page.video();
  await context.close(); // the video file is written when the context closes
  expect(fs.existsSync(await video!.path())).toBe(true);
});

test.describe('annotations and conditional execution', () => {
  test('add annotations at runtime (appear in the HTML report)', async ({ page, browserName }) => {
    test.info().annotations.push({ type: 'browser', description: browserName });
    await page.goto('/');
    await expect(page).toHaveTitle(/Home/);
  });

  test('test.slow() triples the timeout for a known slow test', async ({ page }) => {
    test.slow();
    await page.goto('/dynamic.html');
    await page.getByRole('button', { name: 'Load data' }).click();
    await expect(page.getByTestId('slow-result')).toHaveText(/Loaded/);
  });

  test('skip on a condition (e.g. environment)', async ({ page }) => {
    test.skip(process.env.TEST_ENV === 'staging', 'Demo data only exists locally');
    await page.goto('/table.html');
    await expect(page.locator('tbody tr')).toHaveCount(5);
  });

  test('handle browser-specific behaviour with browserName', async ({ page, browserName }) => {
    await page.goto('/elements.html');

    // Different browsers report different user agents – branch on browserName when needed.
    const userAgent = await page.evaluate(() => navigator.userAgent);
    const expectedEngine = { chromium: /Chrome/, firefox: /Firefox/, webkit: /AppleWebKit/ }[browserName];
    expect(userAgent).toMatch(expectedEngine);

    // OS-specific shortcuts: "ControlOrMeta" = Meta (⌘) on macOS, Control on Windows/Linux.
    const field = page.getByLabel('Prefilled field');
    await field.click();
    await field.press('ControlOrMeta+a');
    await field.press('Delete');
    await expect(field).toHaveValue('');
  });
});

test.describe('handling flaky tests', () => {
  /*
   * Common causes of flakiness and their fixes:
   *   - Fixed sleeps                 → web-first assertions
   *   - Non-unique / brittle locators → role/label/test-id locators
   *   - Shared state between tests   → independent tests, unique data, fixtures
   *   - Random / time-based data     → mock with page.route() or addInitScript
   *   - Asserting before the app is ready → wait for the response/condition
   * Retries (config `retries`) HIDE flakiness; they are a safety net, not a fix.
   * A test that fails then passes on retry is reported as "flaky" in the report.
   */
  test.describe.configure({ retries: 1 });

  test('retry demo – fails on the first attempt when DEMO_FLAKY=1', async ({ page }, testInfo) => {
    // Run:  DEMO_FLAKY=1 npx playwright test -g "retry demo" --project=chromium
    // and the report will show this test as "flaky" (failed once, passed on retry).
    if (process.env.DEMO_FLAKY === '1' && testInfo.retry === 0) {
      throw new Error('Simulated flaky failure on the first attempt');
    }
    await page.goto('/');
    await expect(page).toHaveTitle(/Home/);
  });

  test('random data made stable with mocking (instead of retrying)', async ({ page }) => {
    await page.route('**/api/quote', (route) => route.fulfill({ json: { quote: 'Always the same' } }));
    await page.goto('/dynamic.html');
    await page.getByRole('button', { name: 'Get quote' }).click();
    await expect(page.getByTestId('quote')).toHaveText('Always the same');
  });

  test('capture console errors to help debug failures', async ({ page }) => {
    const errors: string[] = [];
    page.on('console', (msg) => {
      if (msg.type() === 'error') errors.push(msg.text());
    });
    page.on('pageerror', (error) => errors.push(error.message)); // uncaught exceptions

    await page.goto('/forms.html');
    await page.evaluate(() => console.error('Something went wrong in the app'));

    await expect.poll(() => errors).toContain('Something went wrong in the app');
  });
});
