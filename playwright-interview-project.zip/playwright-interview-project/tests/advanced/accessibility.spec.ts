import { test, expect } from '@playwright/test';

/**
 * MODULE 14 – ACCESSIBILITY TESTING WITH BUILT-IN TOOLS
 *
 * 1. ARIA snapshots: compare the accessibility tree (roles + names) to a YAML template.
 *    toMatchAriaSnapshot() is a partial match – list only what you care about.
 * 2. Role-based locators double as accessibility checks: if getByRole('button', { name })
 *    can't find your button, a screen-reader user can't either.
 * 3. For automated WCAG rule checks, add the @axe-core/playwright package (not included
 *    here to keep dependencies minimal) – see README.
 */

test('login form matches the expected accessibility tree', async ({ page }) => {
  await page.goto('/login.html');

  // Tip: don't write templates by hand – print one with `await locator.ariaSnapshot()`
  // (see below) or record it with codegen, then delete the lines you don't care about.
  // Nesting must match the page (the button sits inside a <p> → "paragraph"),
  // but omitted children/attributes (placeholders, the empty alert) are fine.
  await expect(page.locator('form')).toMatchAriaSnapshot(`
    - text: Username
    - textbox "Username"
    - text: Password
    - textbox "Password"
    - paragraph:
      - button "Log in"
  `);
});

test('navigation landmark exposes all main links', async ({ page }) => {
  await page.goto('/');

  await expect(page.getByRole('navigation', { name: 'Main' })).toMatchAriaSnapshot(`
    - navigation "Main":
      - link "Home"
      - link "Login"
      - link "Dashboard"
      - link "Forms"
      - link "Elements"
      - link "Tables"
      - link "Dynamic"
      - link "Alerts"
      - link "Frames"
      - link "Shadow DOM"
      - link "Windows"
      - link "Advanced"
  `);
});

test('ariaSnapshot() returns the tree as text (useful for debugging and creating templates)', async ({ page }) => {
  await page.goto('/alerts.html');
  const snapshot = await page.getByRole('main').ariaSnapshot();

  expect(snapshot).toContain('heading "JavaScript dialogs"');
  expect(snapshot).toContain('button "Show alert"');
});

test('every form field has an accessible name', async ({ page }) => {
  await page.goto('/forms.html');

  for (const field of await page.locator('input:not([type=hidden]), select, textarea').all()) {
    await expect(field).toHaveAccessibleName(/.+/);
  }
});
