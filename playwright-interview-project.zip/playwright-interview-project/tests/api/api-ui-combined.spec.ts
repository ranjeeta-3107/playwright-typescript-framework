import { test, expect } from '@playwright/test';
import { buildProduct, STORAGE_STATE, users } from '../../utils/test-data';

/**
 * MODULE 12 – COMBINING API AND UI
 *
 * Use the API for SETUP and CLEANUP (fast, reliable) and the UI only for the
 * behaviour you actually want to test.
 */

test.use({ storageState: STORAGE_STATE });

test('product created through the API appears in the UI', async ({ page, request }) => {
  // ARRANGE (API): log in and create test data
  const login = await request.post('/api/login', { data: users.standard });
  const { token } = await login.json();
  const headers = { Authorization: `Bearer ${token}` };
  const product = buildProduct({ price: 321 });
  const created = await (await request.post('/api/products', { data: product, headers })).json();

  try {
    // ACT + ASSERT (UI)
    await page.goto('/dashboard.html');
    await page.getByLabel('Search products').fill(product.name);
    const row = page.getByTestId('product-row').filter({ hasText: product.name });
    await expect(row).toHaveCount(1);
    await expect(row).toContainText('$321');
  } finally {
    // CLEANUP (API) – runs even if an assertion above failed
    await request.delete(`/api/products/${created.id}`, { headers });
  }
});

test('UI and API agree: the page uses the same session as page.request', async ({ page }) => {
  await page.goto('/dashboard.html');

  // page.request shares cookies with the browser context → it is logged in too.
  const me = await page.request.get('/api/me');
  expect(me.status()).toBe(200);
  const user = await me.json();
  await expect(page.getByTestId('welcome-message')).toHaveText(`Welcome, ${user.name}`);
});
