import { test, expect, type APIRequestContext } from '@playwright/test';
import { buildProduct, users, type Product } from '../../utils/test-data';

/**
 * MODULE 12 – API TESTING WITH APIRequestContext
 *
 * The built-in `request` fixture is an APIRequestContext that:
 *   - uses `baseURL` from the config
 *   - does NOT need a browser page (fast!)
 *   - keeps cookies between calls (like a browser would)
 *
 * Methods: get, post, put, patch, delete, head, fetch.
 * Options: data (JSON body), params (query string), headers, form, multipart, timeout.
 */

/** Small helper: log in through the API and return a Bearer token. */
async function getToken(request: APIRequestContext): Promise<string> {
  const response = await request.post('/api/login', { data: users.standard });
  expect(response.ok()).toBeTruthy();
  const body = await response.json();
  return body.token;
}

test.describe('read-only endpoints', () => {
  test('GET a list – status, headers and JSON body', async ({ request }) => {
    const response = await request.get('/api/products');

    expect(response.status()).toBe(200);
    expect(response.ok()).toBeTruthy(); // true for any 2xx status
    expect(response.headers()['content-type']).toContain('application/json');

    const products: Product[] = await response.json();
    expect(Array.isArray(products)).toBe(true);
    expect(products).toContainEqual(expect.objectContaining({ id: 1, name: 'Laptop', price: 999 }));
  });

  test('GET with query parameters and a response header', async ({ request }) => {
    const response = await request.get('/api/products', { params: { category: 'Electronics', search: 'board' } });

    const products: Product[] = await response.json();
    expect(products).toHaveLength(1);
    expect(products[0].name).toBe('Keyboard');
    expect(response.headers()['x-total-count']).toBe('1'); // header names are lower-case
  });

  test('GET a single resource and validate its shape', async ({ request }) => {
    const response = await request.get('/api/products/4');
    const product = await response.json();

    expect(product).toEqual({ id: 4, name: 'Coffee Mug', category: 'Kitchen', price: 12, inStock: true });
    expect(typeof product.price).toBe('number');
  });

  test('GET an unknown id returns 404 with an error message', async ({ request }) => {
    const response = await request.get('/api/products/99999');
    expect(response.status()).toBe(404);
    expect(await response.json()).toEqual({ error: 'Product not found' });
  });

  test('send custom headers and read them back', async ({ request }) => {
    const response = await request.get('/api/echo', {
      headers: { 'X-Request-Id': 'abc-123' },
      params: { page: 2 },
    });
    const body = await response.json();
    expect(body.headers['x-request-id']).toBe('abc-123');
    expect(body.query).toEqual({ page: '2' });
  });

  test('paginated endpoint', async ({ request }) => {
    const response = await request.get('/api/employees', { params: { page: 2, limit: 10 } });
    const body = await response.json();
    expect(body).toMatchObject({ page: 2, limit: 10, total: 23, totalPages: 3 });
    expect(body.data).toHaveLength(10);
    expect(body.data[0].id).toBe(11);
  });
});

test.describe('authentication', () => {
  test('write endpoints require authentication (401 without a token)', async ({ request }) => {
    const response = await request.post('/api/products', { data: buildProduct() });
    expect(response.status()).toBe(401);
  });

  test('login returns a token and sets a session cookie', async ({ request }) => {
    const response = await request.post('/api/login', { data: users.standard });
    expect(response.status()).toBe(200);
    expect((await response.json()).token).toMatch(/^[a-f0-9]{32}$/);
    expect(response.headers()['set-cookie']).toContain('session=');
  });

  test('invalid credentials return 401', async ({ request }) => {
    const response = await request.post('/api/login', { data: { username: 'student', password: 'nope' } });
    expect(response.status()).toBe(401);
  });
});

test.describe('CRUD with a Bearer token', () => {
  test('POST → GET → PUT → PATCH → DELETE a product', async ({ request }) => {
    const token = await getToken(request);
    const auth = { Authorization: `Bearer ${token}` };

    // CREATE
    const newProduct = buildProduct({ price: 50 });
    const created = await request.post('/api/products', { data: newProduct, headers: auth });
    expect(created.status()).toBe(201);
    const product: Product = await created.json();
    expect(product).toMatchObject({ ...newProduct }); // spread: interfaces lack an index signature
    expect(created.headers()['location']).toBe(`/api/products/${product.id}`);

    // READ
    const fetched = await request.get(`/api/products/${product.id}`);
    expect(await fetched.json()).toEqual(product);

    // UPDATE (PUT replaces the whole resource)
    const replaced = await request.put(`/api/products/${product.id}`, {
      headers: auth,
      data: { name: `${product.name} v2`, category: 'Test Data', price: 60, inStock: false },
    });
    expect(replaced.status()).toBe(200);
    expect(await replaced.json()).toMatchObject({ price: 60, inStock: false });

    // PARTIAL UPDATE (PATCH changes only the given fields)
    const patched = await request.patch(`/api/products/${product.id}`, { headers: auth, data: { price: 75 } });
    expect(await patched.json()).toMatchObject({ name: `${product.name} v2`, price: 75 });

    // DELETE
    const deleted = await request.delete(`/api/products/${product.id}`, { headers: auth });
    expect(deleted.status()).toBe(204);

    // VERIFY it is gone
    expect((await request.get(`/api/products/${product.id}`)).status()).toBe(404);
  });

  test('validation errors return 400 with details', async ({ request }) => {
    const token = await getToken(request);
    const response = await request.post('/api/products', {
      headers: { Authorization: `Bearer ${token}` },
      data: { name: '', price: -5 },
    });

    expect(response.status()).toBe(400);
    const body = await response.json();
    expect(body.errors).toEqual(
      expect.arrayContaining(['name is required', 'price must be a non-negative number', 'category is required']),
    );
  });
});

test('a standalone APIRequestContext with default headers', async ({ playwright, baseURL }) => {
  // Useful outside tests (global setup, scripts) or when you need different defaults.
  const api = await playwright.request.newContext({
    baseURL,
    extraHTTPHeaders: { Accept: 'application/json', 'X-Client': 'interview-project' },
  });
  const body = await (await api.get('/api/echo')).json();
  expect(body.headers['x-client']).toBe('interview-project');
  await api.dispose();
});
