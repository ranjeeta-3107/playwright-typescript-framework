import { test, expect } from '@playwright/test';

/**
 * MODULE 3 – ELEMENT STATES: enabled / disabled, visible / hidden, editable, checked.
 *
 * Prefer the retrying assertions (toBeEnabled, toBeVisible, ...) over reading the state
 * once with isEnabled() / isVisible(), which return immediately without waiting.
 */

test.beforeEach(async ({ page }) => {
  await page.goto('/elements.html');
});

test('disabled → enabled', async ({ page }) => {
  const button = page.getByRole('button', { name: 'Disabled button' });
  await expect(button).toBeDisabled();

  await page.getByRole('button', { name: 'Enable it' }).click();
  await expect(button).toBeEnabled();
});

test('visible → hidden → visible', async ({ page }) => {
  const message = page.getByTestId('toggle-message');
  const toggle = page.getByRole('button', { name: 'Toggle message' });

  await expect(message).toBeVisible();
  await toggle.click();
  await expect(message).toBeHidden();
  await toggle.click();
  await expect(message).toBeVisible();
});

test('editable vs read-only, checked vs unchecked', async ({ page }) => {
  await expect(page.getByLabel('Prefilled field')).toBeEditable();
  await expect(page.getByLabel('Read-only field')).not.toBeEditable();
  await expect(page.getByLabel('Subscribe to newsletter')).toBeChecked();
});

test('isVisible() / isEnabled() return the state RIGHT NOW (no waiting)', async ({ page }) => {
  // Useful for branching logic, NOT for assertions.
  const delayed = page.getByTestId('delayed-message');
  await page.getByRole('button', { name: 'Show delayed element' }).click();

  // Immediately after the click the element is still hidden – isVisible() does not wait.
  expect(await delayed.isVisible()).toBe(false);

  // The web-first assertion waits (up to the expect timeout) until it appears.
  await expect(delayed).toBeVisible();
});

test('actions on a disabled element wait, then time out with a clear error', async ({ page }) => {
  const disabled = page.getByRole('button', { name: 'Disabled button' });

  // click() waits for the "enabled" actionability check. With a short timeout we can see it fail.
  const error = await disabled.click({ timeout: 1_000 }).catch((e: Error) => e);
  expect(String(error)).toContain('not enabled');
});
