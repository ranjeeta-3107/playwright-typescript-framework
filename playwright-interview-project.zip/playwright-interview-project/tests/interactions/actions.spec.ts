import { test, expect } from '@playwright/test';

/**
 * MODULE 3 – WEB ELEMENT INTERACTIONS
 *
 * Every action (click, fill, check, ...) AUTO-WAITS for the element to be
 * attached, visible, stable, enabled and able to receive events before acting.
 * You never need a sleep before clicking.
 */

test.describe('mouse actions', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/elements.html');
  });

  test('click()', async ({ page }) => {
    // `exact: true` is needed: by default names match as substrings, so "Click me" would
    // also match "Double-click me" and "Right-click me" (→ strict mode violation).
    const button = page.getByRole('button', { name: 'Click me', exact: true });
    await button.click();
    await button.click();
    await expect(page.getByTestId('click-result')).toHaveText('Clicked 2 time(s)');
  });

  test('dblclick()', async ({ page }) => {
    await page.getByRole('button', { name: 'Double-click me' }).dblclick();
    await expect(page.getByTestId('click-result')).toHaveText('Double-clicked!');
  });

  test('right click with click({ button: "right" })', async ({ page }) => {
    await page.getByRole('button', { name: 'Right-click me' }).click({ button: 'right' });
    await expect(page.getByTestId('click-result')).toHaveText('Right-clicked!');
  });

  test('hover() shows a tooltip', async ({ page }) => {
    const tooltip = page.getByTestId('tooltip');
    await expect(tooltip).toBeHidden();

    await page.getByTestId('hover-target').hover();
    await expect(tooltip).toBeVisible();
  });

  test('dragTo() – drag one element onto another', async ({ page }) => {
    await page.getByTestId('draggable').dragTo(page.getByTestId('drop-zone'));
    await expect(page.getByTestId('drop-zone')).toHaveText('Dropped!');
  });
});

test.describe('keyboard and text input', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/elements.html');
  });

  test('fill() replaces the value; clear() empties it', async ({ page }) => {
    const field = page.getByLabel('Prefilled field');
    await expect(field).toHaveValue('Clear me');

    await field.clear();
    await expect(field).toHaveValue('');

    await field.fill('New value'); // fill() clears first, then types the whole value at once
    await expect(field).toHaveValue('New value');
  });

  test('press() – single keys and key combinations', async ({ page }) => {
    const logger = page.getByLabel('Key logger');

    await logger.press('Enter');
    await expect(page.getByTestId('last-key')).toHaveText('Last key: Enter');

    await logger.press('Control+a');
    await expect(page.getByTestId('last-key')).toHaveText('Last key: Control+a');
  });

  test('pressSequentially() – type character by character (fires key events)', async ({ page }) => {
    // Use when the app reacts to each keystroke (autocomplete, masks). Otherwise prefer fill().
    const logger = page.getByLabel('Key logger');
    await logger.pressSequentially('abc');
    await expect(logger).toHaveValue('abc');
    await expect(page.getByTestId('last-key')).toHaveText('Last key: c');
  });

  test('focus() and blur()', async ({ page }) => {
    const field = page.getByLabel('Focus field');

    await field.focus();
    await expect(field).toBeFocused();
    await expect(page.getByTestId('focus-status')).toHaveText('Input is focused');

    await field.blur();
    await expect(page.getByTestId('focus-status')).toHaveText('Input is not focused');
  });
});

test.describe('checkboxes, radios and dropdowns', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/forms.html');
  });

  test('check() and uncheck()', async ({ page }) => {
    const reading = page.getByRole('checkbox', { name: 'Reading' });

    await reading.check();
    await expect(reading).toBeChecked();

    await reading.uncheck();
    await expect(reading).not.toBeChecked();

    // setChecked(boolean) is handy in data-driven tests.
    await reading.setChecked(true);
    await expect(reading).toBeChecked();
  });

  test('radio buttons – checking one unchecks the others', async ({ page }) => {
    await page.getByLabel('Male', { exact: true }).check();
    await page.getByLabel('Other').check();

    await expect(page.getByLabel('Other')).toBeChecked();
    await expect(page.getByLabel('Male', { exact: true })).not.toBeChecked();
  });

  test('selectOption() – by value, by label, by index, multiple', async ({ page }) => {
    const country = page.getByLabel('Country');

    await country.selectOption('us'); // by value
    await expect(country).toHaveValue('us');

    await country.selectOption({ label: 'Germany' }); // by visible text
    await expect(country).toHaveValue('de');

    await country.selectOption({ index: 1 }); // by position
    await expect(country).toHaveValue('in');

    // Multi-select: pass an array
    const skills = page.getByLabel('Skills');
    await skills.selectOption(['playwright', 'api']);
    await expect(skills).toHaveValues(['playwright', 'api']);
  });
});
