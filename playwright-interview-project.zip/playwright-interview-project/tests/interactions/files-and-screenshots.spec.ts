import fs from 'node:fs';
import { test, expect } from '@playwright/test';

/**
 * MODULE 3 – FILE UPLOAD, FILE DOWNLOAD AND SCREENSHOTS
 *
 * testInfo.outputPath(...) gives a unique folder per test inside `test-results/`,
 * so parallel tests never overwrite each other's files.
 */

test.describe('file upload', () => {
  test('setInputFiles() with a file from disk', async ({ page }, testInfo) => {
    const filePath = testInfo.outputPath('resume.txt');
    fs.writeFileSync(filePath, 'My resume');

    await page.goto('/elements.html');
    await page.getByLabel('Upload files').setInputFiles(filePath);

    await expect(page.getByTestId('uploaded-files')).toHaveText('resume.txt (9 bytes)');
  });

  test('setInputFiles() with in-memory files (no file on disk needed)', async ({ page }) => {
    await page.goto('/elements.html');
    const upload = page.getByLabel('Upload files');

    await upload.setInputFiles([
      { name: 'a.txt', mimeType: 'text/plain', buffer: Buffer.from('aaa') },
      { name: 'b.csv', mimeType: 'text/csv', buffer: Buffer.from('id\n1') },
    ]);
    await expect(page.getByTestId('uploaded-files').getByRole('listitem')).toHaveText([
      'a.txt (3 bytes)',
      'b.csv (4 bytes)',
    ]);

    // An empty array clears the selection.
    await upload.setInputFiles([]);
    await expect(page.getByTestId('uploaded-files').getByRole('listitem')).toHaveCount(0);
  });

  test('filechooser event – when there is no visible <input type=file> to target', async ({ page }) => {
    await page.goto('/elements.html');

    // Start waiting BEFORE the click that opens the chooser.
    const fileChooserPromise = page.waitForEvent('filechooser');
    await page.getByLabel('Upload files').click();
    const fileChooser = await fileChooserPromise;

    await fileChooser.setFiles({ name: 'photo.png', mimeType: 'image/png', buffer: Buffer.from('png') });
    await expect(page.getByTestId('uploaded-files')).toContainText('photo.png');
  });
});

test('file download – wait for the download event and save the file', async ({ page }, testInfo) => {
  await page.goto('/elements.html');

  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('link', { name: 'Download report' }).click();
  const download = await downloadPromise;

  expect(download.suggestedFilename()).toBe('report.csv');

  const savedPath = testInfo.outputPath(download.suggestedFilename());
  await download.saveAs(savedPath);
  const content = fs.readFileSync(savedPath, 'utf-8');
  expect(content).toContain('Login test,passed');
});

test.describe('screenshots', () => {
  test('page, full page and element screenshots', async ({ page }, testInfo) => {
    await page.goto('/forms.html');

    // Viewport screenshot saved to a file
    await page.screenshot({ path: testInfo.outputPath('viewport.png') });

    // Whole scrollable page
    await page.screenshot({ path: testInfo.outputPath('full-page.png'), fullPage: true });

    // A single element
    await page.getByRole('heading', { name: 'Registration form' }).screenshot({ path: testInfo.outputPath('heading.png') });

    // Attach a screenshot to the HTML report (shows up under the test)
    await testInfo.attach('form screenshot', { body: await page.screenshot(), contentType: 'image/png' });

    expect(fs.existsSync(testInfo.outputPath('full-page.png'))).toBe(true);
  });

  /*
   * Visual regression (pixel comparison) uses:
   *   await expect(page).toHaveScreenshot('forms.png');
   * The first run creates a baseline image; later runs compare against it.
   * Baselines are OS/browser specific, so they are not committed in this project.
   * Update baselines with:  npx playwright test --update-snapshots
   */
});
