import { test, expect } from '@playwright/test';

/**
 * MODULE 1 – RUNNING TESTS: describe groups, test.only, test.skip, tags, and
 * how to run exactly what you want from the terminal.
 *
 *   npx playwright test                                    # everything, all browsers
 *   npx playwright test --project=chromium                 # one browser
 *   npx playwright test tests/basics                       # one folder
 *   npx playwright test tests/basics/test-execution.spec.ts  # one file
 *   npx playwright test test-execution.spec.ts:25          # the test at line 25
 *   npx playwright test -g "smoke group"                   # tests whose title matches
 *   npx playwright test --grep @smoke                      # tests with a tag
 *   npx playwright test --headed                           # watch the browser
 *   npx playwright test --list                             # list tests without running them
 */

test.describe('smoke group', () => {
  // A tag can be passed in the details object. Filter with --grep @smoke
  test('home page loads', { tag: '@smoke' }, async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Playwright Practice App' })).toBeVisible();
  });

  test('login page loads', { tag: '@smoke' }, async ({ page }) => {
    await page.goto('/login.html');
    await expect(page.getByRole('button', { name: 'Log in' })).toBeVisible();
  });
});

test.describe('skipping tests', () => {
  // test.skip(title, fn) – the test is reported as "skipped" and never runs.
  test.skip('feature not built yet – skipped unconditionally', async ({ page }) => {
    await page.goto('/reports.html');
  });

  // Conditional skip from inside a test: the most common real-world form.
  test('runs everywhere except WebKit', async ({ page, browserName }) => {
    test.skip(browserName === 'webkit', 'Example: a feature that is not supported in Safari');

    await page.goto('/');
    await expect(page).toHaveTitle(/Home/);
  });

  // test.fixme = "known broken, fix later". It is skipped and shows up as such in the report.
  test.fixme('known bug: page /reports.html does not exist yet', async ({ page }) => {
    await page.goto('/reports.html');
    await expect(page.getByRole('heading', { name: 'Reports' })).toBeVisible();
  });
});

/*
 * test.only – runs ONLY the marked test(s) in the whole run. Great while debugging:
 *
 *   test.only('the one I am debugging', async ({ page }) => { ... });
 *
 * It is not used for real in this project because `forbidOnly: true` in CI mode
 * fails the build if a `test.only` is committed by mistake.
 */
