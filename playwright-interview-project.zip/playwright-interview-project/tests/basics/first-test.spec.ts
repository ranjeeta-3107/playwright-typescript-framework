import { test, expect } from '@playwright/test';

/**
 * MODULE 1 – PLAYWRIGHT BASICS: your first tests.
 *
 * - `test(title, async ({ page }) => { ... })` declares a test.
 * - `{ page }` is a FIXTURE: Playwright creates a fresh, isolated browser page
 *   for every test and closes it afterwards.
 * - `expect(...)` makes assertions. Assertions on locators/pages are "web-first":
 *   they retry automatically until they pass or time out.
 *
 * Run only this file:   npx playwright test tests/basics/first-test.spec.ts
 */

test('home page has the correct title', async ({ page }) => {
  // `baseURL` from playwright.config.ts is prepended to relative URLs.
  await page.goto('/');

  await expect(page).toHaveTitle('Practice App | Home');
});

test('home page shows the main heading', async ({ page }) => {
  await page.goto('/');

  await expect(page.getByRole('heading', { level: 1 })).toHaveText('Playwright Practice App');
});

test('user can navigate from home to the login page', async ({ page }) => {
  await page.goto('/');

  // Scope the search to the list of practice pages (the nav bar also has a "Login" link).
  await page.getByRole('list', { name: 'Practice pages' }).getByRole('link', { name: 'Login' }).click();

  await expect(page).toHaveURL(/\/login\.html$/);
  await expect(page.getByRole('heading', { name: 'Sign in' })).toBeVisible();
});

test('expect() also works for plain values (non-retrying assertions)', async () => {
  // Generic assertions like toBe / toEqual check a value ONCE – they do not retry.
  const browsers = ['chromium', 'firefox', 'webkit'];

  expect(browsers).toHaveLength(3);
  expect(browsers).toContain('webkit');
  expect(1 + 1).toBe(2);
});
