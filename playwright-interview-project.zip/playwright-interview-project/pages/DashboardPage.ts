import { expect, type Locator, type Page } from '@playwright/test';

/** Page Object for the dashboard (visible only after login). */
export class DashboardPage {
  readonly heading: Locator;
  readonly welcomeMessage: Locator;
  readonly logoutButton: Locator;
  readonly searchInput: Locator;
  readonly categorySelect: Locator;
  readonly productTable: Locator;
  readonly productRows: Locator;
  readonly productCount: Locator;

  constructor(private readonly page: Page) {
    this.heading = page.getByRole('heading', { name: 'Dashboard' });
    this.welcomeMessage = page.getByTestId('welcome-message');
    this.logoutButton = page.getByRole('button', { name: 'Log out' });
    this.searchInput = page.getByLabel('Search products');
    this.categorySelect = page.getByLabel('Category');
    this.productTable = page.getByRole('table', { name: 'Products' });
    this.productRows = page.getByTestId('product-row');
    this.productCount = page.getByTestId('product-count');
  }

  async goto(): Promise<void> {
    await this.page.goto('/dashboard.html');
  }

  async expectLoggedInAs(displayName: string): Promise<void> {
    await expect(this.page).toHaveURL(/dashboard/);
    await expect(this.welcomeMessage).toHaveText(`Welcome, ${displayName}`);
  }

  async logout(): Promise<void> {
    await this.logoutButton.click();
  }

  /** Returns the table row that contains the product name (a Locator, not an element). */
  rowFor(productName: string): Locator {
    return this.productRows.filter({ hasText: productName });
  }

  /** Types into search and waits for the matching API call, so callers get fresh results. */
  async search(text: string): Promise<void> {
    // Compare the decoded query parameter (spaces may be encoded as "+" or "%20").
    const response = this.page.waitForResponse((res) => {
      const url = new URL(res.url());
      return url.pathname === '/api/products' && url.searchParams.get('search') === text.trim();
    });
    await this.searchInput.fill(text);
    await response;
  }

  async filterByCategory(category: string): Promise<void> {
    await this.categorySelect.selectOption(category);
  }

  /** Deletes a product through the UI. The app asks for confirmation with a `confirm()` dialog. */
  async deleteProduct(productName: string): Promise<void> {
    this.page.once('dialog', (dialog) => dialog.accept());
    await this.rowFor(productName).getByRole('button', { name: 'Delete' }).click();
    await expect(this.rowFor(productName)).toHaveCount(0);
  }
}
