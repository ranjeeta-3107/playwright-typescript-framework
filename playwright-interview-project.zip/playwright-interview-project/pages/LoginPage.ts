import { expect, type Locator, type Page } from '@playwright/test';

/**
 * Page Object for the login page.
 *
 * A Page Object keeps two things in ONE place:
 *  1. Locators  – how to find elements on this page.
 *  2. Actions   – what a user can do on this page (login, read the error, ...).
 * If the UI changes, only this class needs to be updated, not every test.
 */
export class LoginPage {
  // `readonly` = assigned once in the constructor, never re-assigned.
  readonly usernameInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  readonly errorMessage: Locator;
  readonly logoutMessage: Locator;

  // `private readonly page` creates and assigns a property in one step (parameter property).
  constructor(private readonly page: Page) {
    this.usernameInput = page.getByLabel('Username');
    this.passwordInput = page.getByLabel('Password');
    this.loginButton = page.getByRole('button', { name: 'Log in' });
    this.errorMessage = page.getByTestId('login-error');
    this.logoutMessage = page.getByText('You have been logged out');
  }

  async goto(): Promise<void> {
    await this.page.goto('/login.html');
  }

  async login(username: string, password: string): Promise<void> {
    await this.usernameInput.fill(username);
    await this.passwordInput.fill(password);
    await this.loginButton.click();
  }

  /** Assertions in page objects are optional – keep them small and reusable. */
  async expectErrorMessage(message: string): Promise<void> {
    await expect(this.errorMessage).toHaveText(message);
  }
}
