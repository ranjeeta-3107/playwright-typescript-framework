/**
 * Practice App — a tiny, zero-dependency demo application for Playwright practice.
 *
 * Why a local app? Public demo sites go down, change their HTML, rate-limit you
 * or reset their data. A local app gives every test predictable, stable data.
 * Playwright starts this server automatically (see `webServer` in playwright.config.ts).
 *
 * Run it manually:  npm run demo-app   →  http://localhost:3000
 *
 * NOTE: This file is plain JavaScript on purpose (no build step). It is the
 * "application under test", not part of the test framework.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

// ---------------------------------------------------------------------------
// In-memory data
// ---------------------------------------------------------------------------
// Demo-only accounts. These are NOT real secrets — they exist only in this local app.
const USERS = {
  student: { password: 'Password123!', name: 'Student User', role: 'user', locked: false },
  admin: { password: 'Admin123!', name: 'Admin User', role: 'admin', locked: false },
  locked_user: { password: 'Password123!', name: 'Locked User', role: 'user', locked: true },
};

const SEED_PRODUCTS = [
  { id: 1, name: 'Laptop', category: 'Electronics', price: 999, inStock: true },
  { id: 2, name: 'Headphones', category: 'Electronics', price: 199, inStock: true },
  { id: 3, name: 'Keyboard', category: 'Electronics', price: 79, inStock: false },
  { id: 4, name: 'Coffee Mug', category: 'Kitchen', price: 12, inStock: true },
  { id: 5, name: 'Desk Lamp', category: 'Home', price: 45, inStock: true },
  { id: 6, name: 'Notebook', category: 'Stationery', price: 5, inStock: true },
];
let products = SEED_PRODUCTS.map((p) => ({ ...p }));
let nextProductId = 100;

const DEPARTMENTS = ['Engineering', 'Sales', 'Marketing', 'Finance', 'Support'];
const FIRST = ['Aarav', 'Diya', 'Kabir', 'Meera', 'Rohan', 'Sara', 'Vihaan', 'Anika', 'Ishaan', 'Zara', 'Arjun', 'Nisha'];
const EMPLOYEES = Array.from({ length: 23 }, (_, i) => {
  const first = FIRST[i % FIRST.length];
  return {
    id: i + 1,
    name: `${first} ${String.fromCharCode(65 + (i % 26))}.`,
    email: `${first.toLowerCase()}${i + 1}@example.com`,
    department: DEPARTMENTS[i % DEPARTMENTS.length],
    status: i % 4 === 0 ? 'Inactive' : 'Active',
  };
});

const QUOTES = [
  'Tests are a safety net, not a straitjacket.',
  'Flaky tests are worse than no tests.',
  'Automate the boring stuff first.',
  'A good locator describes what the user sees.',
];

const sessions = new Map(); // token -> username

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
};

function sendJson(res, status, body, extraHeaders = {}) {
  res.writeHead(status, { 'Content-Type': MIME['.json'], ...extraHeaders });
  res.end(body === undefined ? '' : JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve) => {
    let raw = '';
    req.on('data', (chunk) => (raw += chunk));
    req.on('end', () => {
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch {
        resolve({ __invalidJson: true });
      }
    });
  });
}

function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach((part) => {
    const [k, ...v] = part.trim().split('=');
    if (k) out[k] = decodeURIComponent(v.join('='));
  });
  return out;
}

/** Accepts either the `session` cookie (browser) or `Authorization: Bearer <token>` (API). */
function currentUser(req) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : parseCookies(req).session;
  const username = token && sessions.get(token);
  return username ? { username, ...publicUser(username) } : null;
}

function publicUser(username) {
  const u = USERS[username];
  return { name: u.name, role: u.role };
}

function validateProduct(body, partial = false) {
  const errors = [];
  if (!partial || body.name !== undefined) {
    if (typeof body.name !== 'string' || body.name.trim() === '') errors.push('name is required');
  }
  if (!partial || body.price !== undefined) {
    if (typeof body.price !== 'number' || body.price < 0) errors.push('price must be a non-negative number');
  }
  if (!partial || body.category !== undefined) {
    if (typeof body.category !== 'string' || body.category.trim() === '') errors.push('category is required');
  }
  return errors;
}

function serveStatic(req, res, pathname) {
  const file = pathname === '/' ? '/index.html' : pathname;
  const fullPath = path.normalize(path.join(PUBLIC_DIR, file));
  if (!fullPath.startsWith(PUBLIC_DIR)) return sendJson(res, 403, { error: 'Forbidden' });
  fs.readFile(fullPath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': MIME['.html'] });
      return res.end('<!doctype html><title>Not Found</title><h1>404 - Page not found</h1>');
    }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(fullPath)] || 'application/octet-stream' });
    res.end(data);
  });
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------
async function handleApi(req, res, url) {
  const { pathname, searchParams } = url;
  const method = req.method;

  if (pathname === '/health') return sendJson(res, 200, { status: 'ok' });

  // --- Authentication -------------------------------------------------------
  if (pathname === '/api/login' && method === 'POST') {
    const { username, password } = await readBody(req);
    const user = USERS[username];
    if (!user || user.password !== password) {
      return sendJson(res, 401, { error: 'Invalid username or password' });
    }
    if (user.locked) return sendJson(res, 403, { error: 'This account is locked' });
    const token = crypto.randomBytes(16).toString('hex');
    sessions.set(token, username);
    return sendJson(
      res,
      200,
      { token, user: { username, ...publicUser(username) } },
      { 'Set-Cookie': `session=${token}; HttpOnly; Path=/; SameSite=Lax` },
    );
  }

  if (pathname === '/api/logout' && method === 'POST') {
    const token = parseCookies(req).session;
    if (token) sessions.delete(token);
    return sendJson(res, 200, { message: 'Logged out' }, { 'Set-Cookie': 'session=; Path=/; Max-Age=0' });
  }

  if (pathname === '/api/me' && method === 'GET') {
    const user = currentUser(req);
    return user ? sendJson(res, 200, user) : sendJson(res, 401, { error: 'Not authenticated' });
  }

  // --- Products (CRUD) -------------------------------------------------------
  if (pathname === '/api/products' && method === 'GET') {
    const search = (searchParams.get('search') || '').toLowerCase();
    const category = searchParams.get('category');
    const result = products.filter(
      (p) => p.name.toLowerCase().includes(search) && (!category || p.category === category),
    );
    return sendJson(res, 200, result, { 'X-Total-Count': String(result.length) });
  }

  if (pathname === '/api/products' && method === 'POST') {
    if (!currentUser(req)) return sendJson(res, 401, { error: 'Not authenticated' });
    const body = await readBody(req);
    const errors = validateProduct(body);
    if (errors.length) return sendJson(res, 400, { errors });
    const product = {
      id: nextProductId++,
      name: body.name,
      category: body.category,
      price: body.price,
      inStock: body.inStock ?? true,
    };
    products.push(product);
    return sendJson(res, 201, product, { Location: `/api/products/${product.id}` });
  }

  const productMatch = pathname.match(/^\/api\/products\/(\d+)$/);
  if (productMatch) {
    const id = Number(productMatch[1]);
    const index = products.findIndex((p) => p.id === id);
    if (method === 'GET') {
      return index === -1 ? sendJson(res, 404, { error: 'Product not found' }) : sendJson(res, 200, products[index]);
    }
    if (!currentUser(req)) return sendJson(res, 401, { error: 'Not authenticated' });
    if (index === -1) return sendJson(res, 404, { error: 'Product not found' });

    if (method === 'PUT') {
      const body = await readBody(req);
      const errors = validateProduct(body);
      if (errors.length) return sendJson(res, 400, { errors });
      products[index] = { id, name: body.name, category: body.category, price: body.price, inStock: body.inStock ?? true };
      return sendJson(res, 200, products[index]);
    }
    if (method === 'PATCH') {
      const body = await readBody(req);
      const errors = validateProduct(body, true);
      if (errors.length) return sendJson(res, 400, { errors });
      products[index] = { ...products[index], ...body, id };
      return sendJson(res, 200, products[index]);
    }
    if (method === 'DELETE') {
      products.splice(index, 1);
      res.writeHead(204);
      return res.end();
    }
  }

  // --- Employees (paginated) -------------------------------------------------
  if (pathname === '/api/employees' && method === 'GET') {
    const page = Math.max(1, Number(searchParams.get('page')) || 1);
    const limit = Math.max(1, Number(searchParams.get('limit')) || 5);
    const start = (page - 1) * limit;
    return sendJson(res, 200, {
      page,
      limit,
      total: EMPLOYEES.length,
      totalPages: Math.ceil(EMPLOYEES.length / limit),
      data: EMPLOYEES.slice(start, start + limit),
    });
  }

  // --- Misc helpers for waits / network demos --------------------------------
  if (pathname === '/api/slow' && method === 'GET') {
    const delay = Math.min(Number(searchParams.get('delay')) || 1000, 5000);
    return setTimeout(() => sendJson(res, 200, { message: `Loaded after ${delay}ms` }), delay);
  }

  if (pathname === '/api/quote' && method === 'GET') {
    // Random on purpose: tests should MOCK this endpoint to get stable data.
    return sendJson(res, 200, { quote: QUOTES[Math.floor(Math.random() * QUOTES.length)] });
  }

  if (pathname === '/api/echo') {
    const body = method === 'GET' ? undefined : await readBody(req);
    return sendJson(res, 200, {
      method,
      query: Object.fromEntries(searchParams),
      headers: req.headers,
      body,
    });
  }

  if (pathname === '/api/register' && method === 'POST') {
    const body = await readBody(req);
    return sendJson(res, 201, { message: `Registration successful for ${body.fullName}`, received: body });
  }

  if (pathname === '/download/report.csv') {
    res.writeHead(200, {
      'Content-Type': 'text/csv',
      'Content-Disposition': 'attachment; filename="report.csv"',
    });
    return res.end('id,name,status\n1,Login test,passed\n2,Checkout test,failed\n');
  }

  return false; // not an API route
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const handled = await handleApi(req, res, url);
  if (handled === false) serveStatic(req, res, url.pathname);
});

server.listen(PORT, () => {
  console.log(`Practice App running at http://localhost:${PORT}`);
});
