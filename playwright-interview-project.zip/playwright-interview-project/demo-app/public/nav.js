// Shared header + theme handling for every page of the Practice App.
(function () {
  const links = [
    ['/', 'Home'], ['/login.html', 'Login'], ['/dashboard.html', 'Dashboard'], ['/forms.html', 'Forms'],
    ['/elements.html', 'Elements'], ['/table.html', 'Tables'], ['/dynamic.html', 'Dynamic'],
    ['/alerts.html', 'Alerts'], ['/frames.html', 'Frames'], ['/shadow.html', 'Shadow DOM'],
    ['/windows.html', 'Windows'], ['/advanced.html', 'Advanced'],
  ];
  const nav = links.map(([href, text]) => `<a href="${href}">${text}</a>`).join('');
  document.body.insertAdjacentHTML(
    'afterbegin',
    `<header class="site"><nav aria-label="Main">${nav}</nav></header>`,
  );
  let theme = 'light';
  try { theme = localStorage.getItem('theme') || 'light'; } catch (e) { /* storage blocked */ }
  if (theme === 'dark') document.body.classList.add('dark');
})();
