import { test as base, expect, type APIRequestContext } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';
import { buildProduct, users, type Product } from '../utils/test-data';
import { getBaseUrl } from '../utils/env';

/**
 * CUSTOM FIXTURES
 *
 * A fixture = something a test needs, prepared before the test and cleaned up after it.
 * Tests just ask for it by name:  test('...', async ({ loginPage, api }) => { ... })
 *
 * Shape of every fixture:
 *   myFixture: async ({ otherFixtures }, use) => {
 *     const value = ...setup...;
 *     await use(value);          // ← the test runs here
 *     ...teardown...;            // runs after the test, even if it failed
 *   }
 *
 * Fixtures are created LAZILY – only when a test actually asks for them.
 * Scope: 'test' (default, new for every test) or 'worker' (once per worker process).
 */

type TestFixtures = {
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
  /** API client already authenticated with a Bearer token. */
  api: APIRequestContext;
  /** A product created through the API before the test and deleted after it. */
  testProduct: Product;
};

type WorkerFixtures = {
  /** Logs in through the API ONCE per worker and shares the token with all its tests. */
  apiToken: string;
};

export const test = base.extend<TestFixtures, WorkerFixtures>({
  // Page Object fixtures: no more `new LoginPage(page)` in every test.
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },

  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },

  // Worker-scoped fixture: the tuple form [fn, options] sets the scope.
  // Worker fixtures can only depend on other worker fixtures (like `playwright`), not on `page`.
  apiToken: [
    async ({ playwright }, use) => {
      const request = await playwright.request.newContext({ baseURL: getBaseUrl() });
      const response = await request.post('/api/login', { data: users.standard });
      expect(response.ok(), 'API login should succeed').toBeTruthy();
      const { token } = await response.json();
      await request.dispose();
      await use(token);
    },
    { scope: 'worker' },
  ],

  api: async ({ playwright, baseURL, apiToken }, use) => {
    const api = await playwright.request.newContext({
      baseURL,
      extraHTTPHeaders: { Authorization: `Bearer ${apiToken}` },
    });
    await use(api);
    await api.dispose(); // teardown
  },

  testProduct: async ({ api }, use) => {
    // SETUP – create data through the API (fast and reliable compared with the UI).
    const response = await api.post('/api/products', { data: buildProduct() });
    expect(response.status()).toBe(201);
    const product: Product = await response.json();

    await use(product);

    // TEARDOWN – always clean up. 404 is fine if the test itself deleted it.
    const cleanup = await api.delete(`/api/products/${product.id}`);
    expect([204, 404]).toContain(cleanup.status());
  },
});

export { expect };
