/**
 * Reusable test data.
 *
 * Rules followed here:
 *  - Credentials come from environment variables (never hard-coded in tests).
 *  - Data is typed with interfaces, so typos are caught by TypeScript.
 *  - Unique values (timestamps) keep parallel tests from clashing.
 */

export interface UserCredentials {
  username: string;
  password: string;
}

export interface Product {
  id?: number;
  name: string;
  category: string;
  price: number;
  inStock?: boolean;
}

export interface RegistrationData {
  fullName: string;
  email: string;
  password: string;
  gender: 'Male' | 'Female' | 'Other';
  country: string;
}

/** Reads a required environment variable and fails with a clear message if it is missing. */
export function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing environment variable "${name}". Copy .env.example to .env and fill it in.`);
  }
  return value;
}

/** Valid accounts (read lazily so a missing variable only fails the tests that need it). */
export const users = {
  get standard(): UserCredentials {
    return { username: requireEnv('APP_USERNAME'), password: requireEnv('APP_PASSWORD') };
  },
  get admin(): UserCredentials {
    return { username: requireEnv('ADMIN_USERNAME'), password: requireEnv('ADMIN_PASSWORD') };
  },
};

/** Display names the Practice App shows for each account. */
export const displayNames = {
  standard: 'Student User',
  admin: 'Admin User',
};

/** Data-driven negative login cases. `error` is the message the app shows. */
export const invalidLogins: Array<{ title: string; username: string; password: string; error: string }> = [
  { title: 'wrong password', username: 'student', password: 'wrong-password', error: 'Invalid username or password' },
  { title: 'unknown user', username: 'nobody', password: 'whatever', error: 'Invalid username or password' },
  { title: 'locked account', username: 'locked_user', password: 'Password123!', error: 'This account is locked' },
  { title: 'empty username', username: '', password: 'Password123!', error: 'Username and password are required' },
  { title: 'empty password', username: 'student', password: '', error: 'Username and password are required' },
];
// NOTE: the locked user's password above is a deliberately public value of the demo app,
// used only to prove the "locked" branch. Real secrets always come from requireEnv().

/** Where the authentication setup project saves the logged-in browser state. */
export const STORAGE_STATE = 'playwright/.auth/user.json';

/** Builds a unique product so parallel tests never collide. */
export function buildProduct(overrides: Partial<Product> = {}): Product {
  const unique = `${Date.now()}-${Math.floor(Math.random() * 10_000)}`;
  return { name: `Test Product ${unique}`, category: 'Test Data', price: 25, inStock: true, ...overrides };
}

export const validRegistration: RegistrationData = {
  fullName: 'Asha Verma',
  email: 'asha.verma@example.com',
  password: 'SuperSecret1',
  gender: 'Female',
  country: 'India',
};
