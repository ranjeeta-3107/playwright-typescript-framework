/**
 * Environment helpers shared by playwright.config.ts and fixtures.
 *
 * TEST_ENV picks a known environment; BASE_URL (if set) overrides it.
 * Functions (not constants) are used so values are read AFTER the .env file is loaded.
 */
export const ENVIRONMENTS: Record<string, string> = {
  local: 'http://localhost:3000',
  staging: 'https://staging.example.com', // placeholder – replace with your real environment
};

export function getBaseUrl(): string {
  const testEnv = process.env.TEST_ENV ?? 'local';
  return process.env.BASE_URL ?? ENVIRONMENTS[testEnv] ?? ENVIRONMENTS.local;
}
